package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/8/8.
 */

public class DeviceInfo extends Object {
    public String platform;
    public String osVer;
    public String appver;
    public String wifissid;
    public String macAddress;
    public String SIMcarrier;
    public String netWorkType;
    public String imei;
    public String phone;

    public DeviceInfo() {
    }
}
