package com.colin.webbridge.demo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.TelephonyManager;

import com.colin.webbridge.demo.bean.DeviceInfo;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.NetUtils;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/**
 * Created by Administrator on 2017/8/11.
 */

public class AppUtil {
    @SuppressLint("HardwareIds")
    public static DeviceInfo getDeviceInfo(Activity activity) {
        DeviceInfo deviceInfo = new DeviceInfo();
        deviceInfo.platform = Build.MODEL;
        deviceInfo.osVer = Build.MODEL;
        deviceInfo.appver = "Android:" + Build.VERSION.RELEASE;
        TelephonyManager telephonyManager = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
        deviceInfo.phone = telephonyManager.getLine1Number();
        deviceInfo.imei = telephonyManager.getDeviceId();
        String operator = telephonyManager.getSimOperator();
        if (null == operator) {
            deviceInfo.SIMcarrier = "读取失败";
        }
        if (operator.equals("46000") || operator.equals("46002") || operator.equals("46007")) {
            deviceInfo.SIMcarrier = "中国移动";
        } else if (operator.equals("46001")) {
            deviceInfo.SIMcarrier = "中国联通";
        } else if (operator.equals("46003")) {
            deviceInfo.SIMcarrier = "中国电信";
        } else {
            deviceInfo.SIMcarrier = operator;
        }

        if (NetUtils.getNetworkType(activity) == 6) {
            deviceInfo.netWorkType = "4G";
        } else if (NetUtils.getNetworkType(activity) == 5) {
            deviceInfo.netWorkType = "3G";
        } else if (NetUtils.getNetworkType(activity) == 4) {
            deviceInfo.netWorkType = "2G";
        } else if (NetUtils.getNetworkType(activity) == 3) {
            deviceInfo.netWorkType = "wifi";
        } else if (NetUtils.getNetworkType(activity) == 2) {
            deviceInfo.netWorkType = "以太网";
        } else if (NetUtils.getNetworkType(activity) == 1) {
            deviceInfo.netWorkType = "网络断开或关闭";
        } else if (NetUtils.getNetworkType(activity) == 0) {
            deviceInfo.netWorkType = "没有网络连接";
        } else {
            deviceInfo.netWorkType = "未知网络";
        }

        @SuppressLint("WifiManagerLeak") WifiManager wifiManager = (WifiManager) activity.getSystemService(Context.WIFI_SERVICE);
        if (null != wifiManager) {
            WifiInfo wifiInfo = wifiManager.getConnectionInfo();
            if (null != wifiInfo) {
                deviceInfo.wifissid = wifiInfo.getSSID();
            } else {
                deviceInfo.wifissid = "wifiInfo获取失败";
            }
        } else {
            deviceInfo.wifissid = "wifiManager获取失败";
        }
//        deviceInfo.macAddress = getMacAddr();
        return deviceInfo;
    }

    public static String getMacAddr() {
        try {
            List<NetworkInterface> all = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface nif : all) {
                if (!nif.getName().equalsIgnoreCase("wlan0")) continue;
                byte[] macBytes = nif.getHardwareAddress();
                if (macBytes == null) {
                    return "";
                }
                StringBuilder res1 = new StringBuilder();
                for (byte b : macBytes) {
                    res1.append(String.format("%02X:", b));
                }

                if (res1.length() > 0) {
                    res1.deleteCharAt(res1.length() - 1);
                }
                return res1.toString();
            }
        } catch (Exception ex) {
            LogUtil.e(ex.getMessage());
        }
        return "02:00:00:00:00:00";
    }







}
