package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/7/18.
 */

public class PhoneBean {
    public String phoneNumber;
}
