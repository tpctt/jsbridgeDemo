package com.colin.webbridge.demo.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2017/7/21.
 */

public class ContactBean extends Object {
    private String username;
    private List<String> phones = new ArrayList<>();

    public ContactBean() {
    }

    public ContactBean(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<String> getPhones() {
        return phones;
    }

    public void setPhones(List<String> phones) {
        this.phones = phones;
    }

    public void setPhones(String string) {

    }
}
