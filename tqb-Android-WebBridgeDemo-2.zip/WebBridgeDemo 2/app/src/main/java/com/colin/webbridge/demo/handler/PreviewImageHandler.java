package com.colin.webbridge.demo.handler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.colin.webbridge.demo.imagepreview.ImagePreviewActivity;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.PermissionUtil;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by hbl on 2017/5/11.
 */

public class PreviewImageHandler extends DefaultHandler {
    private Activity mActivity;
    private CallBackFunction mCallBackFunction;
    private BridgeInterface mBridgeInterface;
    private String path = "";
    private UrlListBean mUrlListBean;
    private List<String> urls;

    @SuppressLint("NewApi")
    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        mActivity = bridgeInterface.getActivity();
        mCallBackFunction = function;
        mBridgeInterface = bridgeInterface;
        mUrlListBean = new Gson().fromJson(data, UrlListBean.class);
        showImage();
    }

    public void showImage() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_STORAGE), REQUEST_CODE_PERMISSION_STORAGE)) {
            return;
        }
        if (null != mUrlListBean && null != mUrlListBean.getUrls() && mUrlListBean.getUrls().size() > 0) {
            Intent intent = new Intent(mActivity, ImagePreviewActivity.class);
            Bundle bundle = new Bundle();
            bundle.putInt("currentItem", 0);
            bundle.putStringArrayList("list", mUrlListBean.getUrls());
            intent.putExtras(bundle);
            mActivity.startActivity(intent);
        }

    }

    private class UrlListBean {
        ArrayList<String> urls;

        public ArrayList<String> getUrls() {
            return urls;
        }

        public void setUrls(ArrayList<String> urls) {
            this.urls = urls;
        }
    }

}