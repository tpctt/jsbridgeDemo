package com.colin.webbridge.demo.handler;

import android.graphics.Color;
import android.view.View;
import android.widget.TextView;

import com.colin.webbridge.demo.bean.ButtonBean;
import com.colin.webridge.library.WebViewBridge;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.WebUrlUtil;
import com.google.gson.Gson;

/**
 * Created by hbl on 2017/5/11.
 */

public class RightNavigationButtonHandler extends DefaultHandler {
    private WebViewBridge mWebViewBridge;
    private TextView mTextView;

    public RightNavigationButtonHandler(WebViewBridge webViewBridge, TextView view) {
        this.mWebViewBridge = webViewBridge;
        this.mTextView = view;
        this.mTextView.setVisibility(View.INVISIBLE);
    }


    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        showNavigationBar(new Gson().fromJson(data, ButtonBean.class));
    }

    public void showNavigationBar(final ButtonBean buttonBean) {
        if (null == buttonBean) {
            mTextView.setVisibility(View.INVISIBLE);
            return;
        }
        mTextView.setText(buttonBean.getTitle());
        mTextView.setTextColor(Color.parseColor(buttonBean.getFrontColor()));
        mTextView.setVisibility(View.VISIBLE);
        mTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mWebViewBridge.callHandler(WebUrlUtil.BRIDGE_KEY_SET_NAVBAR_RIGHT_BTN_TWO, buttonBean.getActivePath(), new CallBackFunction() {
                    @Override
                    public void onCallBack(String data) {
                        LogUtil.e(data);
                    }
                });
            }
        });
    }

}