package com.colin.webbridge.demo.imagepreview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.colin.webbridge.demo.R;

import java.util.List;


public class ImagePreviewAdapter extends PagerAdapter {
    private ViewGroup containerParent;
    private List<String> imageInfo;
    private Context context;
    private int current = 0;
    private SparseArray<ImageView> mImageViewSparseArray;
    private SparseArray<View> mViewSparseArray;

    public ImagePreviewAdapter(Context context, @NonNull List<String> imageInfo) {
        super();
        this.imageInfo = imageInfo;
        this.context = context;
        mImageViewSparseArray = new SparseArray<>();
        mViewSparseArray = new SparseArray<>();
    }

    @Override
    public int getCount() {
        return imageInfo.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void setPrimaryItem(ViewGroup container, int position, Object object) {
        super.setPrimaryItem(container, position, object);
        current = position;
        this.containerParent = container;
    }

    public View getPrimaryItem() {
        return mViewSparseArray.get(current, null);
    }

    public ImageView getPrimaryImageView() {
        return mImageViewSparseArray.get(current, null);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = mViewSparseArray.get(position);
        if (null == view) {
            view = LayoutInflater.from(context).inflate(R.layout.fragment_image_preview, container, false);
            final ProgressBar progressBar = (ProgressBar) view.findViewById(R.id.progress_image_preview);
            final TouchImageView imageView = (TouchImageView) view.findViewById(R.id.image_fragment_preview);

            //如果需要加载的loading,需要自己改写,不能使用这个方法
            ImageLoader.getInstance().loadImage(imageView, this.imageInfo.get(position));
            //监听
            imageView.setOnSingleClickListener(new TouchImageView.OnSingleClickListener() {
                @Override
                public void onSingleClick(View view) {
                    if (view instanceof TouchImageView) {
                        ((ImagePreviewActivity) context).finish();
                    }
                }
            });
            //赋值
            mImageViewSparseArray.put(position, imageView);
            mViewSparseArray.put(position, view);
            view.setTag(position);
            container.addView(view);
        }
        return view;
    }

    @Override
    public int getItemPosition(Object object) {
        return POSITION_NONE;
    }


    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
        mImageViewSparseArray.removeAt(position);
        mViewSparseArray.removeAt(position);
    }

}