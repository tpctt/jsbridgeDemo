package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/8/11.
 */

public class ContactHistoryBean extends Object {
    public String name; // 短信序号，如100
    public String number;// 发件人地址，即手机号，如+86138138000
    public String date;// 短信内容
    public String duration; // 联系人姓名列表序号
    public String type;// 日期，long型，如1346988516，可以对日期显示格式进行设置

    @Override
    public String toString() {
        return "ContactHistoryBean{" +
                "name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", date='" + date + '\'' +
                ", duration='" + duration + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
