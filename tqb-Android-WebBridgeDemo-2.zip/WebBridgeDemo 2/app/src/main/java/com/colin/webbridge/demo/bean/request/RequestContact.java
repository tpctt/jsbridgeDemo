package com.colin.webbridge.demo.bean.request;

import com.colin.webbridge.demo.bean.ContactBean;

import java.util.List;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestContact extends RequestBase {

    private List<ContactBean> data;

    public RequestContact(int code) {
        super(code);
    }

    public RequestContact(int code, String msg) {
        super(code, msg);
    }

    public List<ContactBean> getData() {
        return data;
    }

    public void setData(List<ContactBean> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
