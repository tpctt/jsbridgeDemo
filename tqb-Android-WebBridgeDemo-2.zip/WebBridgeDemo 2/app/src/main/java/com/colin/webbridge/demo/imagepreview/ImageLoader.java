package com.colin.webbridge.demo.imagepreview;

import com.bumptech.glide.Glide;
import com.colin.webridge.library.utils.LogUtil;

/**
 * Created by Administrator on 2017/7/20.
 */

public class ImageLoader {
    private ImageLoader() {
    }

    public static class Holder {
        static ImageLoader instance = new ImageLoader();
    }

    public static ImageLoader getInstance() {
        return Holder.instance;
    }

    /**
     * Glide.with()使用
     * <p>
     * with(Context context).                           使用Application上下文，Glide请求将不受Activity/Fragment生命周期控制。
     * with(Activity mContext).                         使用Activity作为上下文，Glide的请求会受到Activity生命周期控制。
     * with(FragmentActivity mContext).                 Glide的请求会受到FragmentActivity生命周期控制。
     * with(android.app.Fragment fragment).             Glide的请求会受到Fragment 生命周期控制。
     * with(android.support.v4.app.Fragment fragment).  Glide的请求会受到Fragment生命周期控制
     *
     * @param imageView
     * @param url
     */
    public void loadImage(TouchImageView imageView, String url) {
        LogUtil.e(url);
        Glide.with(imageView.getContext())
                .load(url)
                .into(imageView);
    }
}
