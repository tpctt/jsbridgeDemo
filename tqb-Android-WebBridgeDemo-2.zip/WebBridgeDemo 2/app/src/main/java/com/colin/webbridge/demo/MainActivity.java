package com.colin.webbridge.demo;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.colin.webbridge.demo.bean.UrlBean;
import com.colin.webridge.library.utils.SharedPreferencesUtil;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private ListView list_main_choose;
    private EditText edit_main_url;
    private TextView text_main_url_submit;
    private List<UrlBean> mUrlBeanList = new ArrayList<UrlBean>();
    private UrlAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initListener();
    }

    private void initView() {
        edit_main_url = (EditText) findViewById(R.id.edit_main_url);
        text_main_url_submit = (TextView) findViewById(R.id.text_main_url_submit);
        list_main_choose = (ListView) findViewById(R.id.list_main_choose);
        initListView();
    }

    private void initListView() {
        initData();
        adapter = new UrlAdapter(mUrlBeanList);
        list_main_choose.setAdapter(adapter);


    }

    private void initData() {
        UrlBean demo = new UrlBean("Demo", "http://test.taoqian123.com.cn/");
        UrlBean demo1 = new UrlBean("Demo-layout", "http://192.168.1.197/taoqian123/wap/web/layout");
        UrlBean demo2 = new UrlBean("Demo-3000", "http://192.168.1.197:3000/");
        UrlBean jsp = new UrlBean("第三方JSP", "http://test.taoqian123.com.cn/jsp/");
        UrlBean download = new UrlBean("本地测试", "file:///android_asset/demo.html");
        mUrlBeanList.add(demo);
        mUrlBeanList.add(demo1);
        mUrlBeanList.add(demo2);
        mUrlBeanList.add(jsp);
        mUrlBeanList.add(download);
        //获取本地缓存的URL
        Set<String> urls = SharedPreferencesUtil.get(this, "urls", new HashSet<String>());
        String[] objects = new String[urls.size()];
        urls.toArray(objects);
        for (String url : urls) {
            UrlBean data = new UrlBean("测试", url);
            if (mUrlBeanList.contains(data)) continue;
            mUrlBeanList.add(data);
        }
    }

    private void initListener() {
        text_main_url_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = edit_main_url.getText().toString().trim();
                if (TextUtils.isEmpty(url)) return;
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra("url", url);
                startActivity(intent);
                //本地缓存
                Set<String> urls = SharedPreferencesUtil.get(MainActivity.this, "urls", new HashSet<String>());
                urls.add(url);
                SharedPreferencesUtil.put(MainActivity.this, "urls", urls);
                //更新Adapter
                UrlBean data = new UrlBean("测试", url);
                if (!mUrlBeanList.contains(data)) {
                    mUrlBeanList.add(data);
                    adapter.notifyDataSetChanged();
                }

            }
        });
        list_main_choose.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                UrlBean urlBean = mUrlBeanList.get(position);
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra("url", urlBean.url);
                startActivity(intent);
            }
        });
        list_main_choose.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                if (mUrlBeanList.get(position).name.contains("测试")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("删除此条目")
                            .setNegativeButton("确定", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Set<String> urls = SharedPreferencesUtil.get(MainActivity.this, "urls", new HashSet<String>());
                                    urls.remove(mUrlBeanList.get(position));
                                    SharedPreferencesUtil.put(MainActivity.this, "urls", urls);
                                    mUrlBeanList.remove(position);
                                    adapter.notifyDataSetChanged();
                                }
                            }).create().show();
                    return true;
                } else {
                    return false;
                }
            }
        });
    }


    private class UrlAdapter extends BaseAdapter {
        private List<UrlBean> datas = new ArrayList<>();

        public UrlAdapter() {
        }

        public UrlAdapter(List<UrlBean> datas) {
            this.datas = datas;
        }

        @Override
        public int getCount() {
            return null == datas ? 0 : datas.size();
        }

        @Override
        public Object getItem(int position) {
            return datas.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            SelectUrlViewHolder holder;
            if (null == convertView) {
                holder = new SelectUrlViewHolder();
                convertView = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_select_url, parent, false);
                holder.text_item_url_name = (TextView) convertView.findViewById(R.id.text_item_url_name);
                holder.text_item_url_value = (TextView) convertView.findViewById(R.id.text_item_url_value);
                convertView.setTag(holder);
            } else {
                holder = (SelectUrlViewHolder) convertView.getTag();
            }
            holder.text_item_url_name.setText(datas.get(position).name);
            holder.text_item_url_value.setText(datas.get(position).url);
            return convertView;
        }
    }

    private static class SelectUrlViewHolder {
        public TextView text_item_url_name;
        public TextView text_item_url_value;
    }
}
