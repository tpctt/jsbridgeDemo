package com.colin.webbridge.demo.handler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;

import com.colin.webbridge.demo.DemoFileProvider;
import com.colin.webbridge.demo.bean.ChooseImageBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestString;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.Base64Util;
import com.colin.webridge.library.utils.BitmapUtil;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.PermissionUtil;
import com.google.gson.Gson;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Arrays;

/**
 * Created by hbl on 2017/5/11.
 */

public class ChooseImageHandler extends DefaultHandler {
    private Activity mActivity;
    private CallBackFunction mCallBackFunction;
    private BridgeInterface mBridgeInterface;
    private String path = "";

    @SuppressLint("NewApi")
    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        /**
         * 开启相机，添加权限和Android N 的FileProvider，避免冲突使用DemoFileProvider
         */
        mActivity = bridgeInterface.getActivity();
        mCallBackFunction = function;
        mBridgeInterface = bridgeInterface;
        ChooseImageBean chooseImageBean = new Gson().fromJson(data, ChooseImageBean.class);
        if (!TextUtils.isEmpty(chooseImageBean.getSourceType()) && chooseImageBean.getSourceType().equals("camera")) {
            openCamera();
        } else if (!TextUtils.isEmpty(chooseImageBean.getSourceType()) && chooseImageBean.getSourceType().equals("album")) {
            openAlbum();
        } else {
            getCameraImage();
        }
    }

    public void getCameraImage() {
        showDialog();
    }

    private void showDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(mActivity).setItems(new String[]{"相机", "相册"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0:
                        openCamera();
                        break;
                    case 1:
                        openAlbum();
                        break;
                }
            }


        });
        builder.create().show();
    }

    private void openCamera() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_CAMERA), REQUEST_CODE_PERMISSION_CHOOSE)) {
            return;
        }
        path = Environment.getExternalStorageDirectory() + "/Demo/" + System.currentTimeMillis() + ".jpg";
        File imageFile = new File(path);
        if (!imageFile.exists()) {
            imageFile.getParentFile().mkdirs();
        }
        Uri imageUri;
        if (Build.VERSION.SDK_INT >= 24) {
            imageUri = DemoFileProvider.getUriForFile(mActivity, "com.colin.webbridge.demo.provider", imageFile);
        } else {
            imageUri = Uri.fromFile(imageFile);
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.Images.Media.ORIENTATION, 0);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        mBridgeInterface.activityForResult(intent, REQUEST_CODE_CHOOSE_CAMERA);
    }

    private void openAlbum() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_CAMERA), REQUEST_CODE_PERMISSION_CHOOSE)) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");//相片类型
        mBridgeInterface.activityForResult(intent, REQUEST_CODE_CHOOSE_ALBUM);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == REQUEST_CODE_CHOOSE_CAMERA) {
            postImage(path);
        } else if (requestCode == REQUEST_CODE_CHOOSE_ALBUM) {
            if (data == null) return;
            Uri uri = data.getData();
            int sdkVersion = Integer.valueOf(Build.VERSION.SDK);
            if (sdkVersion >= 19) {
                path = uri.getPath();
                path = BitmapUtil.getPath_above19(mActivity, uri);
            } else {
                path = BitmapUtil.getFilePath_below19(mActivity, uri);
            }
            postImage(path);
        }
    }

//    /**
//     * 将文件路径转换为Base64的图片编码，只进行尺寸压缩
//     *
//     * @param path
//     * @return
//     */
//    @SuppressLint("DefaultLocale")
//    private String getBase64FromBitmap(String path) {
//        Bitmap bitmap = BitmapUtil.getBitmap(path, 960, 720);
//        if (bitmap.getHeight() > bitmap.getWidth()) {
//            bitmap = BitmapUtil.rotate(bitmap, -90, bitmap.getWidth() / 2f, bitmap.getHeight() / 2, true);
//        }
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
//        LogUtil.e(String.format("图片的高度：%d\t宽度：%d", bitmap.getHeight(), bitmap.getWidth()));
//        byte[] bytes = baos.toByteArray();
//        String s1 = new String(Base64Util.encode(bytes));
//        return s1;
//    }

    /**
     * 将文件路径转换为Base64的图片编码，只进行尺寸压缩
     *
     * @param path
     * @return
     */
    @SuppressLint("DefaultLocale")
    private void postImage(String path) {
        Bitmap bitmap = BitmapUtil.getBitmap(path, 960, 720);
        if (null == bitmap || bitmap.getHeight() < 1 || bitmap.getWidth() < 1) {
            mCallBackFunction.onCallBack(new RequestString(RequestBase.GET_DATA_FAIL, "图片获取失败").toJson());
        } else {
            if (bitmap.getHeight() > bitmap.getWidth()) {
                bitmap = BitmapUtil.rotate(bitmap, 0, bitmap.getWidth() / 2f, bitmap.getHeight() / 2, true);
            }
            String type = path.substring(path.lastIndexOf("."), path.length());
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);

            LogUtil.e(String.format("图片的高度：%d\t宽度：%d", bitmap.getHeight(), bitmap.getWidth()));
            byte[] bytes = baos.toByteArray();
            mCallBackFunction.onCallBack(new RequestString(new String(Base64Util.encode(bytes))).toJson());
        }

    }

}