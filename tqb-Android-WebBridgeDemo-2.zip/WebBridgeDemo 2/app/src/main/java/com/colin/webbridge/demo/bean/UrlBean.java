package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/7/18.
 */

public class UrlBean {
    public String name;
    public String url;

    public UrlBean(String urlName, String urlValue) {
        this.name = urlName;
        this.url = urlValue;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof UrlBean) {
            return url.equals(((UrlBean) obj).url);
        } else {
            return false;
        }
    }
}
