package com.colin.webbridge.demo.bean.request;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestImage extends RequestBase {

    private String data;

    public RequestImage(int code) {
        super(code);
    }

    public RequestImage(int code, String msg) {
        super(code, msg);
    }

    public RequestImage(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
