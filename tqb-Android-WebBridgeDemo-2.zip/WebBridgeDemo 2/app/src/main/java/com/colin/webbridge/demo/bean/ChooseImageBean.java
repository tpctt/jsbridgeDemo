package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/8/8.
 */

public class ChooseImageBean extends Object {
    private String sourceType;

    public String getSourceType() {
        return sourceType;
    }

    @Override
    public String toString() {
        return "ChooseImageBean{" +
                "sourceType='" + sourceType + '\'' +
                '}';
    }
}
