package com.colin.webbridge.demo.handler;

import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.os.Handler;
import android.os.Message;

import com.colin.webbridge.demo.bean.ContactHistoryBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestContactHistory;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.PermissionUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static android.provider.CallLog.Calls.CACHED_NAME;
import static android.provider.CallLog.Calls.CONTENT_URI;
import static android.provider.CallLog.Calls.DATE;
import static android.provider.CallLog.Calls.DEFAULT_SORT_ORDER;
import static android.provider.CallLog.Calls.DURATION;
import static android.provider.CallLog.Calls.NUMBER;
import static android.provider.CallLog.Calls.TYPE;

/**
 * Created by Administrator on 2017/8/11.
 */

public class ContactHistoryHandler extends DefaultHandler {
    private Activity mActivity;
    private CallBackFunction mFunction = null;
    private List<ContactHistoryBean> mContactHistoryBeenList = new ArrayList<>();
    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            mFunction.onCallBack(new RequestContactHistory(mContactHistoryBeenList).toJson());
        }
    };

    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        mActivity = bridgeInterface.getActivity();
        mFunction = function;
        readContactHistory();
    }

    public void readContactHistory() {

        new Thread(new Runnable() {
            @Override
            public void run() {
                getContactHistory();
            }
        }).start();

    }

    public void getContactHistory() {
        try {


            // 1.获得ContentResolver
            ContentResolver resolver = mActivity.getContentResolver();
            // 2.利用ContentResolver的query方法查询通话记录数据库
            if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_PHONE), REQUEST_CODE_PERMISSION_CONTACT_HISTORY)) {
                mFunction.onCallBack(new RequestContactHistory(RequestBase.GET_DATA_FAIL, "权限获取失败").toJson());
                return;
            }
            /**
             * @param uri 需要查询的URI，（这个URI是ContentProvider提供的）
             * @param projection 需要查询的字段
             * @param selection sql语句where之后的语句
             * @param selectionArgs ?占位符代表的数据
             * @param sortOrder 排序方式
             *
             */
            Cursor cursor = resolver.query(CONTENT_URI, // 查询通话记录的URI
                    new String[]{CACHED_NAME// 通话记录的联系人
                            , NUMBER// 通话记录的电话号码
                            , DATE// 通话记录的日期
                            , DURATION// 通话时长
                            , TYPE}// 通话类型
                    , null, null, DEFAULT_SORT_ORDER// 按照时间逆序排列，最近打的最先显示
            );
            List<ContactHistoryBean> contactHistoryBeanList = new ArrayList<>();
            if (null == cursor) {
                mFunction.onCallBack(new RequestContactHistory(RequestBase.GET_DATA_FAIL, "获取通话记录失败").toJson());
                return;
            }
            ContactHistoryBean contactHistoryBean = null;
            while (cursor.moveToNext()) {
                contactHistoryBean = new ContactHistoryBean();
                contactHistoryBean.name = cursor.getString(cursor.getColumnIndex(CACHED_NAME));
                contactHistoryBean.number = cursor.getString(cursor.getColumnIndex(NUMBER));
                long dateLong = cursor.getLong(cursor.getColumnIndex(DATE));
                contactHistoryBean.date = String.valueOf(dateLong);
//            contactHistoryBean.date = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss", Locale.CHINA).format(new Date(dateLong));
                int duration = cursor.getInt(cursor.getColumnIndex(DURATION));
                contactHistoryBean.duration = String.valueOf(duration);
                int type = cursor.getInt(cursor.getColumnIndex(TYPE));
                contactHistoryBean.type = String.valueOf(type);
//            String typeString = "";
//            switch (type) {
//                case CallLog.Calls.INCOMING_TYPE:
//                    contactHistoryBean.type = "打入";
//                    break;
//                case CallLog.Calls.OUTGOING_TYPE:
//                    typeString = "打出";
//                    break;
//                case CallLog.Calls.MISSED_TYPE:
//                    typeString = "未接";
//                    break;
//                default:
//                    break;
//            }

                mContactHistoryBeenList.add(contactHistoryBean);
            }
            cursor.close();
            for (ContactHistoryBean historyBean : mContactHistoryBeenList) {
                LogUtil.e("historyBean-->>" + historyBean.toString());
            }
            mHandler.sendEmptyMessage(0);
//            mFunction.onCallBack(new RequestContactHistory(contactHistoryBeanList).toJson());
        } catch (Exception e) {
            mFunction.onCallBack(new RequestContactHistory(RequestBase.GET_DATA_FAIL, "获取通话记录失败").toJson());
        }

    }
}
