package com.colin.webbridge.demo.handler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import com.colin.webbridge.demo.DemoFileProvider;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.Base64Util;
import com.colin.webridge.library.utils.BitmapUtil;
import com.colin.webridge.library.utils.PermissionUtil;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.Arrays;

/**
 * Created by hbl on 2017/5/11.
 */

public class PhotoHandler extends DefaultHandler {
    private String path = "";
    private CallBackFunction mCallBackFunction;
    private BridgeInterface mBridgeInterface;
    private Activity mActivity;


    @SuppressLint("NewApi")
    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        /**
         * 开启相机，添加权限和Android N 的FileProvider，避免冲突使用DemoFileProvider
         */
        mActivity = bridgeInterface.getActivity();
        mCallBackFunction = function;
        mBridgeInterface = bridgeInterface;
        bridgeInterface.bindHandler(this);
        getCameraImage();
    }

    public void getCameraImage() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_CAMERA), REQUEST_CODE_PERMISSION_CAMERA)) {
            return;
        }
        path = Environment.getExternalStorageDirectory() + "/Demo/" + System.currentTimeMillis() + ".jpg";
        File imageFile = new File(path);
        if (!imageFile.exists()) {
            imageFile.getParentFile().mkdirs();
        }
        Uri imageUri;
        if (Build.VERSION.SDK_INT >= 24) {
//            imageUri = DemoFileProvider.getUriForFile(mActivity, mActivity.getPackageName() + ".provider", imageFile);
            imageUri = DemoFileProvider.getUriForFile(mActivity, "com.colin.webbridge.demo.provider", imageFile);
        } else {
            imageUri = Uri.fromFile(imageFile);
        }
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.Images.Media.ORIENTATION, 0);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        mBridgeInterface.activityForResult(intent, REQUEST_CODE_CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_CAMERA) {
            String s = getBase64FromBitmap(path);
            mCallBackFunction.onCallBack(s);
        }
    }

    /**
     * 将文件路径转换为Base64的图片编码，只进行尺寸压缩
     *
     * @param path
     * @return
     */
    private String getBase64FromBitmap(String path) {
        Bitmap bitmap = BitmapUtil.getBitmap(path, 960, 720);
        if (bitmap.getHeight() > bitmap.getWidth()) {
            bitmap = BitmapUtil.rotate(bitmap, -90, bitmap.getWidth() / 2f, bitmap.getHeight() / 2, true);
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 50, baos);
        Log.d("TAG", "getBase64FromBitmap: " + bitmap.getWidth() + "/" + bitmap.getHeight());
        byte[] bytes = baos.toByteArray();
        String s1 = new String(Base64Util.encode(bytes));
        return s1;
    }

}