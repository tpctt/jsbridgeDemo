package com.colin.webbridge.demo.handler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationManager;
import android.provider.Settings;

import com.colin.webbridge.demo.bean.LocationBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestLocation;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.PermissionUtil;

import java.util.Arrays;

import static android.location.LocationManager.GPS_PROVIDER;

/**
 * Created by hbl on 2017/5/11.
 */

public class LocationHandler extends DefaultHandler {

    private Activity mActivity;
    private Location mLocation;
    private CallBackFunction mCallBackFunction;
    private BridgeInterface mBridgeInterface;

    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        mActivity = bridgeInterface.getActivity();
        mCallBackFunction = function;
        mBridgeInterface = bridgeInterface;
        initLocation();
    }

    /**
     * 利用系统定位，每次获取新的，添加权限检查
     * 进行定位
     * provider:
     * 用于定位的locationProvider字符串:
     * LocationManager.NETWORK_PROVIDER / LocationManager.GPS_PROVIDER
     * minTime:
     * 时间更新间隔，单位：ms
     * minDistance:
     * 位置刷新距离，单位：m
     * listener:
     * 用于定位更新的监听者locationListener
     */
    @SuppressLint({"NewApi", "DefaultLocale"})
    public void initLocation() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_LOCATION), REQUEST_CODE_PERMISSION_LOCATION)) {
            return;
        }

        LocationManager locationManager = (LocationManager) mActivity.getSystemService(Context.LOCATION_SERVICE);
        if (null == locationManager.getProvider(LocationManager.NETWORK_PROVIDER) || null == locationManager.getProvider(GPS_PROVIDER)) {
            Intent intent = new Intent();
            intent.setAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            mBridgeInterface.activityForResult(intent, REQUEST_CODE_LOCATION);
        } else {
            mLocation = locationManager.getLastKnownLocation(GPS_PROVIDER);
            if (null == mLocation) {
                mLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                LogUtil.e("GPS_PROVIDER定位失败");
                if (null == mLocation) {
                    mLocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                    LogUtil.e("NETWORK_PROVIDER定位失败");
                }
            }
            if (null == mLocation) {
                LogUtil.e("PASSIVE_PROVIDER定位失败");
                mCallBackFunction.onCallBack(new RequestLocation(RequestBase.GET_DATA_FAIL,"经纬度获取失败：只能使用第三方定位了").toJson());
            } else {
                LocationBean locationBean = new LocationBean(mLocation);
                mCallBackFunction.onCallBack(new RequestLocation(locationBean).toJson());
            }
        }

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_LOCATION) {
            initLocation();
        }
    }

}
