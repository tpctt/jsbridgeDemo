package com.colin.webbridge.demo.bean.request;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestClipboard extends RequestBase {

    private String data;

    public RequestClipboard(int code) {
        super(code);
    }

    public RequestClipboard(int code, String msg) {
        super(code, msg);
    }

    public RequestClipboard(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
