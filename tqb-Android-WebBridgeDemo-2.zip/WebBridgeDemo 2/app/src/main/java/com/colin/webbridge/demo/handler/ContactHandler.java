package com.colin.webbridge.demo.handler;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import com.colin.webbridge.demo.bean.ContactBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestContact;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.PermissionUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by Administrator on 2017/7/20.
 */

public class ContactHandler extends DefaultHandler {
    private CallBackFunction mCallBackFunction;
    private BridgeInterface mBridgeInterface;
    private Activity mActivity;
    private boolean mGetAll = false;

    public ContactHandler() {
    }

    public ContactHandler(boolean getAll) {
        mGetAll = getAll;
    }

    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        mActivity = bridgeInterface.getActivity();
        mCallBackFunction = function;
        mBridgeInterface = bridgeInterface;
        readContact();
    }

    public void readContact() {
        if (mGetAll && !PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_CONTACTS), REQUEST_CODE_PERMISSION_CONTACT_ALL)) {
            return;
        }
        if (!mGetAll && !PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_CONTACTS), REQUEST_CODE_PERMISSION_CONTACT)) {
            return;
        }
        if (mGetAll) {
            getAllContacts(mActivity);
        } else {
            mBridgeInterface.activityForResult(new Intent(Intent.ACTION_PICK, ContactsContract.Contacts.CONTENT_URI), REQUEST_CODE_CONTACT);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE_CONTACT) {
            // ContentProvider展示数据类似一个单个数据库表
            // ContentResolver实例带的方法可实现找到指定的ContentProvider并获取到ContentProvider的数据
            ContentResolver contentResolver = mActivity.getContentResolver();
            // URI,每个ContentProvider定义一个唯一的公开的URI,用于指定到它的数据集
            Uri contactData = data.getData();
            // 查询就是输入URI等参数,其中URI是必须的,其他是可选的,如果系统能找到URI对应的ContentProvider将返回一个Cursor对象.
            //魅族手机查询第二次异常
//            Cursor cursor = mActivity.managedQuery(contactData, null, null, null, null);
            //修改
            Cursor cursor = contentResolver.query(contactData, null, null, null, null);
            if (null != cursor && cursor.getCount() > 0) {
                List<ContactBean> contactBeanList = new ArrayList<>();
                ContactBean contactBean = new ContactBean();
                cursor.moveToFirst();
                // 获得DATA表中的名字
                String username = cursor.getString(cursor
                        .getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                contactBean.setUsername(username);
                // 条件为联系人ID
                String contactId = cursor.getString(cursor
                        .getColumnIndex(ContactsContract.Contacts._ID));
                // 获得DATA表中的电话号码，条件为联系人ID,因为手机号码可能会有多个
                Cursor phoneCursor = contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = " + contactId, null, null);
                StringBuilder stringBuilder = new StringBuilder();
                List<String> phones = new ArrayList<>();
                if (null != phoneCursor && phoneCursor.getCount() > 0) {
                    while (phoneCursor.moveToNext()) {
                        phones.add(phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
                    }
                    contactBean.setPhones(phones);
                    phoneCursor.close();
                }
                cursor.close();
                contactBeanList.add(contactBean);
                RequestContact requestContact = new RequestContact(contactBeanList.size() == 0 ? RequestBase.GET_DATA_FAIL : RequestBase.GET_DATA_SUCCESS);
                requestContact.setData(contactBeanList);
                mCallBackFunction.onCallBack(requestContact.toJson());
            } else {
                mCallBackFunction.onCallBack(new RequestContact(RequestBase.GET_DATA_FAIL, "电话号码读取失败,请检查权限使用").toJson());
            }

        }
    }


    private void getAllContacts(Context context) {
        // 获取联系人数据
        ContentResolver contentResolver = context.getContentResolver();
        //获取所有电话信息（而不是联系人信息），这样方便展示
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = {
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,// 姓名
                ContactsContract.CommonDataKinds.Phone.NUMBER,// 电话号码
        };
        Cursor cursor = contentResolver.query(uri, projection, null, null, null);
        if (null == cursor || cursor.getCount() == 0) {
            mCallBackFunction.onCallBack(new RequestContact(RequestBase.GET_DATA_FAIL, "电话号码读取失败,请检查权限使用").toJson());
            return;
        }
        //最终要返回的数据
        List<ContactBean> contactBeanList = new ArrayList<>();
        ContactBean contactBean = null;
        while (cursor.moveToNext()) {

            String name = cursor.getString(0);
            contactBean = new ContactBean(name);
//            LogUtil.e("name-->>" + name);
//            for (ContactBean bean : contactBeanList) {
//                if (bean.getUsername().equals(name)) {
//                    contactBean = bean;
//                }
//            }
//            if (null == contactBean) {
//                contactBean = new ContactBean(name);
//            }

            List<String> phones = contactBean.getPhones();
            phones.add(cursor.getString(1));
            contactBeanList.add(contactBean);
        }
        cursor.close();
        RequestContact requestContact = new RequestContact(contactBeanList.size() == 0 ? RequestBase.GET_DATA_FAIL : RequestBase.GET_DATA_SUCCESS);
        requestContact.setData(contactBeanList);
        mCallBackFunction.onCallBack(requestContact.toJson());
    }

    private void getContacts(Uri uri) {
        // 获取联系人数据
        ContentResolver contentResolver = mActivity.getContentResolver();
        Cursor cursor = contentResolver.query(uri, null, null, null, null);
        if (null == cursor || cursor.getCount() == 0) {
            mCallBackFunction.onCallBack(new RequestContact(RequestBase.GET_DATA_FAIL, "电话号码读取失败,请检查权限使用").toJson());
            return;
        }
        //最终要返回的数据
        List<ContactBean> contactBeanList = new ArrayList<>();
        ContactBean contactBean = null;
        while (cursor.moveToNext()) {
            // 获得DATA表中的名字
            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
            // 条件为联系人ID
            String contactId = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));
            // 获得DATA表中的电话号码，条件为联系人ID,因为手机号码可能会有多个
            Cursor phoneCursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI
                    , null
                    , ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " = " + name
                    , null
                    , null);
            contactBean = new ContactBean(name);
            List<String> phones = new ArrayList<>();
            if (null != phoneCursor && phoneCursor.getCount() > 0) {
                while (phoneCursor.moveToNext()) {
                    phones.add(phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
                }
                contactBean.setPhones(phones);
                phoneCursor.close();
            }
            contactBeanList.add(contactBean);
        }
        cursor.close();
        RequestContact requestContact = new RequestContact(contactBeanList.size() == 0 ? RequestBase.GET_DATA_FAIL : RequestBase.GET_DATA_SUCCESS);
        requestContact.setData(contactBeanList);
        mCallBackFunction.onCallBack(requestContact.toJson());
    }

}
