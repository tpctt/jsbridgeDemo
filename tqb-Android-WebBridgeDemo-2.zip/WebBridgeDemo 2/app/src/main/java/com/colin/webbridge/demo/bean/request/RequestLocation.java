package com.colin.webbridge.demo.bean.request;

import com.colin.webbridge.demo.bean.LocationBean;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestLocation extends RequestBase {

    private LocationBean data;

    public RequestLocation(int code) {
        super(code);
    }

    public RequestLocation(int code, String msg) {
        super(code, msg);
    }

    public RequestLocation(LocationBean data) {
        this.data = data;
    }

    public LocationBean getData() {
        return data;
    }

    public void setData(LocationBean data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
