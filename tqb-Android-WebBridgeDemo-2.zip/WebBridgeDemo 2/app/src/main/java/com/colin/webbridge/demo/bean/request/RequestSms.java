package com.colin.webbridge.demo.bean.request;


import com.colin.webbridge.demo.bean.SMSBean;

import java.util.List;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestSms extends RequestBase {

    private List<SMSBean> data;

    public RequestSms(int code) {
        super(code);
    }

    public RequestSms(List<SMSBean> data) {
        this.data = data ;
    }

    public RequestSms(int code, String msg) {
        super(code, msg);
    }

    public List<SMSBean> getData() {
        return data;
    }

    public void setData(List<SMSBean> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
