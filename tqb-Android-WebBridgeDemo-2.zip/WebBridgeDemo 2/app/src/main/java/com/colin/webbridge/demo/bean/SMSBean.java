package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/8/11.
 */

public class SMSBean extends Object {
    public String _id; // 短信序号，如100
    public String address;// 发件人地址，即手机号，如+86138138000
    public String body;// 短信内容
    public String person; // 联系人姓名列表序号
    public String date;// 日期，long型，如1346988516，可以对日期显示格式进行设置
    public String protocol; // 对话的序号，如100，与同一个手机号互发的短信，其序号是相同的
    public String read; // 是否阅读0未读，1已读
    public String status; // 短信状态-1接收，0complete,64pending,128faile
    public String type;// 短信类型1是接收到的，2是已发出
    public String service_center; // 短信服务中心号码编号，如+8613800755500

    @Override
    public String toString() {
        return "SMSBean{" +
                "_id='" + _id + '\'' +
                ", address='" + address + '\'' +
                ", body='" + body + '\'' +
                ", person='" + person + '\'' +
                ", date='" + date + '\'' +
                ", protocol='" + protocol + '\'' +
                ", read='" + read + '\'' +
                ", status='" + status + '\'' +
                ", type='" + type + '\'' +
                ", service_center='" + service_center + '\'' +
                '}';
    }
}
