package com.colin.webbridge.demo.handler;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;

import com.colin.webbridge.demo.bean.SMSBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestSms;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.LogUtil;
import com.colin.webridge.library.utils.PermissionUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by hbl on 2017/5/11.
 */

public class SMSHandler extends DefaultHandler {
    private Activity mActivity;
    private CallBackFunction mFunction = null;


    @Override
    public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
        mActivity = bridgeInterface.getActivity();
        mFunction = function;
        readSMS();
    }

    private void readSMS() {
        if (!PermissionUtil.getInstance().checkPermission(mActivity, Arrays.asList(PermissionUtil.PERMISSIONS_SMS), REQUEST_CODE_PERMISSION_SMS)) {
            return;
        }
        mFunction.onCallBack(new RequestSms(getSMSData()).toJson());
    }

    public List<SMSBean> getSMSData() {
        List<SMSBean> sMSBeanList = new ArrayList<>();
        final String SMS_URI_ALL = "content://sms/";
//        final String SMS_URI_INBOX = "content://sms/inbox";
//        final String SMS_URI_SEND = "content://sms/sent";
//        final String SMS_URI_DRAFT = "content://sms/draft";


        ContentResolver cr = mActivity.getContentResolver();

        String[] projection = new String[]{"_id", "address", "body", "person", "date", "protocol", "read", "status", "type", "service_center"};
        Uri uri = Uri.parse(SMS_URI_ALL);
        @SuppressLint("Recycle") Cursor cur = cr.query(uri, projection, null, null, "date desc");
        if (null == cur) {
            mFunction.onCallBack(new RequestSms(RequestBase.GET_DATA_FAIL, "获取短信类容失败").toJson());
            return sMSBeanList;
        }

        if (cur.moveToFirst()) {
            int idColumn = cur.getColumnIndex("_id");
            int addressColumn = cur.getColumnIndex("address");
            int bodyColumn = cur.getColumnIndex("body");
            int personColumn = cur.getColumnIndex("person");
            int dateColumn = cur.getColumnIndex("date");
            int protocolColumn = cur.getColumnIndex("protocol");
            int readColumn = cur.getColumnIndex("read");
            int statusColumn = cur.getColumnIndex("status");
            int typeColumn = cur.getColumnIndex("type");
            int service_centerColumn = cur.getColumnIndex("service_center");
            SMSBean smsBean = null;
            do {
                smsBean = new SMSBean();
                smsBean._id = cur.getString(idColumn);
                smsBean.address = cur.getString(addressColumn);
                smsBean.body = cur.getString(bodyColumn);
                smsBean.person = cur.getString(personColumn);
                smsBean.date = cur.getString(dateColumn);
                smsBean.protocol = cur.getString(protocolColumn);
                smsBean.read = cur.getString(readColumn);
                smsBean.status = cur.getString(statusColumn);
                smsBean.type = cur.getString(typeColumn);
                smsBean.service_center = cur.getString(service_centerColumn);
                sMSBeanList.add(smsBean);
            } while (cur.moveToNext());
        }
        for (SMSBean smsBean : sMSBeanList) {
            LogUtil.e("smsBean-->>" + smsBean.toString());
        }
        return sMSBeanList;
    }

}