package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/7/21.
 */

public class TitleColorBean {

    private String frontColor ;
    private String backgroundColor ;

    public String getFrontColor() {
        return frontColor;
    }

    public void setFrontColor(String frontColor) {
        this.frontColor = frontColor;
    }

    public String getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(String backgroundColor) {
        this.backgroundColor = backgroundColor;
    }
}
