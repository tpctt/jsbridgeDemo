package com.colin.webbridge.demo.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by Colin on 2017/4/24.
 */

public class ShareBean extends Object implements Serializable {
    /**
     * title : 锦城测试产品
     * content : 锦城测试产品 - 我就是描述
     * href : http://m.taoqian123.dev/product/view/81.html?channel_id=26
     * image : http://img.taoqian123.dev/product/20170303/148850807058b8d4a6592bd.jpg
     */

    private String title;       //分享标题

    @SerializedName(value = "content", alternate = "text")
    private String content;     //分享内容

    @SerializedName(value = "href", alternate = "url")
    private String href;        //分享链接

    private String image;       //分享图片
    private String count;

    public ShareBean() {
    }


    public ShareBean(String href, String title, String content, String image, String count) {
        this.title = title;
        this.content = content;
        this.href = href;
        this.image = image;
        this.count = count;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "ShareBean{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", href='" + href + '\'' +
                ", image='" + image + '\'' +
                ", count='" + count + '\'' +
                '}';
    }
}
