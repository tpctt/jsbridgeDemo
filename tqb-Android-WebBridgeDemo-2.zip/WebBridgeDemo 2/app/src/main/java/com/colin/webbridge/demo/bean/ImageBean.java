package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/7/21.
 */

public class ImageBean extends Object {
    private String image ;
    private String type ;
}
