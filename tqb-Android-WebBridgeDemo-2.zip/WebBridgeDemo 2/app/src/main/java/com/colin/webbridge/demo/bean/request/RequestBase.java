package com.colin.webbridge.demo.bean.request;

import android.text.TextUtils;

import com.google.gson.Gson;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestBase extends Object {
    public final static int GET_DATA_FAIL = -1;//系统获取数据失败
    public final static int GET_DATA_SUCCESS = 0;//系统获取数据成功
    public final static int GET_DATA_OTHER = -2;//系统获取数据其他状态

    private int code = 0;//成功
    private String msg = "success";

    public RequestBase() {
    }

    public RequestBase(int code) {
        setCode(code);

    }

    public RequestBase(int code, String msg) {
        this.msg = msg;
        if (TextUtils.isEmpty(msg)) {
            setCode(code);
        } else {
            this.code = code;
        }
    }

    public void setCode(int code) {
        this.code = code;
        if (code == GET_DATA_FAIL) {
            msg = "获取数据失败，请检查相应权限，或者检查是否拥有数据";
        } else if (code == GET_DATA_SUCCESS) {
            msg = "success";
        } else if (code == GET_DATA_OTHER) {
            msg = "success";
        }
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String toJson() {
        return new Gson().toJson(this);
    }

    @Override
    public String toString() {
        return "RequestBase{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                '}';
    }
}
