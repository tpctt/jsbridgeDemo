package com.colin.webbridge.demo.bean.request;

import com.colin.webbridge.demo.bean.DeviceInfo;

/**
 * Created by Administrator on 2017/8/8.
 */

public class RequestDeviceInfo extends RequestBase {
    private DeviceInfo data;

    public RequestDeviceInfo(int code) {
        super(code);
    }

    public RequestDeviceInfo(DeviceInfo data) {
        this.data = data;
    }

    public RequestDeviceInfo(int code, String msg) {
        super(code, msg);
    }

}
