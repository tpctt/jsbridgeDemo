package com.colin.webbridge.demo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.colin.webbridge.demo.bean.PhoneBean;
import com.colin.webbridge.demo.bean.ShareBean;
import com.colin.webbridge.demo.bean.TitleBean;
import com.colin.webbridge.demo.bean.TitleColorBean;
import com.colin.webbridge.demo.bean.UrlBean;
import com.colin.webbridge.demo.bean.request.HtmlRegisterBean;
import com.colin.webbridge.demo.bean.request.RequestBase;
import com.colin.webbridge.demo.bean.request.RequestDeviceInfo;
import com.colin.webbridge.demo.bean.request.RequestString;
import com.colin.webbridge.demo.handler.ChooseImageHandler;
import com.colin.webbridge.demo.handler.ContactHandler;
import com.colin.webbridge.demo.handler.ContactHistoryHandler;
import com.colin.webbridge.demo.handler.LocationHandler;
import com.colin.webbridge.demo.handler.PhotoHandler;
import com.colin.webbridge.demo.handler.PreviewImageHandler;
import com.colin.webbridge.demo.handler.RightNavigationButtonHandler;
import com.colin.webbridge.demo.handler.SMSHandler;
import com.colin.webridge.library.BridgeMessage;
import com.colin.webridge.library.WebViewBridge;
import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;
import com.colin.webridge.library.callback.IWebViewCallBack;
import com.colin.webridge.library.handler.BridgeHandler;
import com.colin.webridge.library.handler.DefaultHandler;
import com.colin.webridge.library.utils.BridgeUtil;
import com.colin.webridge.library.utils.InitViewUtil;
import com.colin.webridge.library.utils.PermissionUtil;
import com.colin.webridge.library.utils.StatusBarUtil;
import com.colin.webridge.library.utils.WebUrlUtil;
import com.google.gson.Gson;

import java.util.Arrays;

public class WebViewActivity extends AppCompatActivity implements BridgeInterface {
    private CollapsingToolbarLayout layout_toolbar;
    private AppBarLayout app_bar;
    private Toolbar toolbar;
    private ImageView image_title_left;
    private LinearLayout linear_title;
    private TextView text_title;
    private TextView text_title_right;
    private ImageView image_web_choose;
    private FloatingActionButton fab_back;
    private ProgressBar progress_bar_web;
    private WebView web_content;
    private String url = "file:///android_asset/demo.html";
    private WebViewBridge webViewBridge;
    private BridgeHandler mPhotoHandler;
    private LocationHandler mLocationHandler;
    private ChooseImageHandler mChooseImageHandler;
    private PreviewImageHandler mPreviewImageHandler;
    private ContactHandler mContactHandler;
    private ContactHandler mAllContactHandler;
    private SMSHandler mSMSHandler;
    private ContactHistoryHandler mContactHistoryHandler;

    private CallBackFunction phoneFunction = null;
    private RightNavigationButtonHandler mRightNavigationButtonHandler;


    private Integer[] colorResArray = new Integer[]{R.color.colorAccent
            , R.color.colorPrimaryDark
            , R.color.colorAccent
            , R.color.white
            , R.color.black
            , android.R.color.transparent
    };

    @Override
    public void onBackPressed() {
        if (null != web_content && web_content.canGoBack()) {
            web_content.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        mLocationHandler = null;
        mPhotoHandler = null;
        mChooseImageHandler = null;
        mPreviewImageHandler = null;
        mContactHandler = null;
        mAllContactHandler = null;
        mRightNavigationButtonHandler = null;
        webViewBridge = null;
        phoneFunction = null;
        mSMSHandler = null;
        mContactHistoryHandler = null;
        if (null != web_content) {
            web_content.setVisibility(View.GONE);
            web_content.destroy();
        }
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);
        initView();
        initListener();
    }

    private void initView() {
        app_bar = (AppBarLayout) this.findViewById(R.id.app_bar);
        layout_toolbar = (CollapsingToolbarLayout) this.findViewById(R.id.layout_toolbar);
        toolbar = (Toolbar) this.findViewById(R.id.toolbar);
        image_title_left = (ImageView) this.findViewById(R.id.image_title_left);
        text_title = (TextView) this.findViewById(R.id.text_title);
        linear_title = (LinearLayout) this.findViewById(R.id.linear_title);
        text_title_right = (TextView) this.findViewById(R.id.text_title_right);
        text_title.setText(R.string.app_name);
        setSupportActionBar(toolbar);
        this.fab_back = (FloatingActionButton) this.findViewById(R.id.fab_back);
        this.web_content = (WebView) this.findViewById(R.id.web_content);
        this.progress_bar_web = (ProgressBar) this.findViewById(R.id.progress_bar_web);
        this.image_web_choose = (ImageView) this.findViewById(R.id.image_web_choose);
        initWebView();
        InitViewUtil.initWebView(web_content, url, new MyWebViewCallBack());

    }

    private void initWebView() {
        url = getIntent().getStringExtra("url");
        //xml注册
        webViewBridge = new WebViewBridge(this, "webviewhandler");
        webViewBridge.bindWebView(web_content);
        //代码注册
        //获取当前的地理位置、速度。当用户离开淘钱宝后，此接口无法调用；
        mLocationHandler = new LocationHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_LOCATION, mLocationHandler);

        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_TOKEN, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack("123");
            }
        });
        //从本地相册选择图片或使用相机拍照。
        mChooseImageHandler = new ChooseImageHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_CHOOSE_IMAGE, mChooseImageHandler);
        //预览图片
        mPreviewImageHandler = new PreviewImageHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_PREVIEW_IMAGE, mPreviewImageHandler);
        //拨打电话号码
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_MAKE_PHONE_CALL, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                PhoneBean phoneBean = new Gson().fromJson(data, PhoneBean.class);
                Uri uri = Uri.parse("tel:" + phoneBean.phoneNumber);
                Intent intent = new Intent(Intent.ACTION_DIAL, uri);
                startActivity(intent);
            }
        });
        //设置剪切板
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SET_CLIPBOARD_DATA, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                //剪切板管理工具类
                ClipboardManager mClipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                //剪切板Data对象
                //创建一个新的文本clip对象
                ClipData mClipData = ClipData.newPlainText("Simple test", data);
                //把clip对象放在剪贴板中
                mClipboardManager.setPrimaryClip(mClipData);
                Toast.makeText(WebViewActivity.this, String.format("复制值(%s)到剪切板成功", data), Toast.LENGTH_SHORT).show();
            }
        });
        //获取剪切板中的内容
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_CLIPBOARD_DATA, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {

                //剪切板管理工具类
                ClipboardManager mClipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData mClipData = mClipboardManager.getPrimaryClip();
                //获取到内容
                String content = "";
                if (null != mClipData && mClipData.getItemCount() > 0) {
                    content = mClipData.getItemAt(mClipData.getItemCount() - 1).getText().toString().trim();
                }
                if (TextUtils.isEmpty(content)) {
                    function.onCallBack(new RequestString(RequestBase.GET_DATA_FAIL, "获取剪切板内容为空").toJson());
                } else {
                    function.onCallBack(new RequestString(content).toJson());
                }
            }
        });

        //获取剪切板中的内容
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SET_NAVIGATION_BAR_TITLE, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                TitleBean title = new Gson().fromJson(data, TitleBean.class);
                text_title.setText(title.getTitle());
            }
        });
        //设置导航栏颜色
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SET_NAVIGATION_BAR_COLOR, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                TitleColorBean titleColorBean = new Gson().fromJson(data, TitleColorBean.class);
                StatusBarUtil.setWindowStatusBarColor(WebViewActivity.this, titleColorBean.getBackgroundColor());
                text_title.setTextColor(Color.parseColor(titleColorBean.getFrontColor()));
                toolbar.setBackgroundColor(Color.parseColor(titleColorBean.getBackgroundColor()));
                layout_toolbar.setContentScrimColor(Color.parseColor(titleColorBean.getBackgroundColor()));
                layout_toolbar.setStatusBarScrimColor(Color.parseColor(titleColorBean.getBackgroundColor()));
                layout_toolbar.setCollapsedTitleTextColor(Color.parseColor(titleColorBean.getFrontColor()));
                layout_toolbar.setExpandedTitleColor(Color.parseColor(titleColorBean.getFrontColor()));
                layout_toolbar.setBackgroundColor(Color.parseColor(titleColorBean.getBackgroundColor()));

            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SHOW_NAVIGATION_BAR, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                app_bar.setVisibility(View.VISIBLE);
                layout_toolbar.setVisibility(View.VISIBLE);
                toolbar.setVisibility(View.VISIBLE);
            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_HIDE_NAVIGATION_BAR, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                linear_title.setVisibility(View.GONE);
                app_bar.setVisibility(View.GONE);
                layout_toolbar.setVisibility(View.GONE);
                toolbar.setVisibility(View.GONE);

            }
        });
        //界面跳转
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_NAVIGATE_TO, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                UrlBean urlBean = new Gson().fromJson(data, UrlBean.class);

                if (urlBean.url.startsWith("http") || urlBean.url.startsWith("https")) {
                    Intent intent = new Intent(WebViewActivity.this, WebViewActivity.class);
                    intent.putExtra("url", urlBean.url);
                    startActivity(intent);
                } else if (urlBean.url.startsWith("tqb")) {
                    Intent intent = new Intent(WebViewActivity.this, WebViewActivity.class);
                    intent.putExtra("url", "https://www.baidu.com");
                    startActivity(intent);
                }

            }
        });
        //当前界面加载网页
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_REDIRECT_TO, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
//                intent.putExtra("url", "http://www.taoqian123.com/test/test?id=1");
                UrlBean urlBean = new Gson().fromJson(data, UrlBean.class);
                web_content.loadUrl(urlBean.url);

            }
        });
        //返回
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_NAVIGATE_BACK, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                onBackPressed();
            }
        });
        //通讯录
        mContactHandler = new ContactHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_CONTACT, mContactHandler);
        mAllContactHandler = new ContactHandler(true);
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_ADDRESS_BOOK, mAllContactHandler);


        //上传版本信息
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_JS_PROXY_VER, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack(new RequestString("V2").toJson());
            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_LOGIN, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack(new RequestString("登录").toJson());

            }
        });

        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_LOGOUT, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack(new RequestString("退出登录").toJson());
            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_USER_INFO, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack(new RequestString("个人信息").toJson());
            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SHARE_INFO, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                ShareBean mShareBean = new Gson().fromJson(data, ShareBean.class);
                Toast.makeText(WebViewActivity.this, mShareBean.getContent(), Toast.LENGTH_SHORT).show();
            }
        });
//        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_OPEN_PRODUCT_VIEW, new DefaultHandler() {
//            @Override
//            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
//                function.onCallBack(new RequestString("贷款产品详情").toJson());
//            }
//        });

        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_DEVICE_INFO, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                phoneFunction = function;
                if (!PermissionUtil.getInstance().checkPermission(WebViewActivity.this, Arrays.asList(PermissionUtil.PERMISSIONS_PHONE), REQUEST_CODE_PERMISSION_PHONE)) {
                    return;
                }
                sendDeviceInfo(true);
            }
        });
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_APP_VERSION_DATA, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                function.onCallBack(new RequestString("V2").toJson());
            }
        });

        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_REGISTER, new DefaultHandler() {
            @Override
            public void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface) {
                HtmlRegisterBean htmlRegisterBean = new Gson().fromJson(data, HtmlRegisterBean.class);
                Bundle bundle = new Bundle();
                bundle.putString("idenify", htmlRegisterBean.idenify);
                Toast.makeText(WebViewActivity.this, htmlRegisterBean.idenify, Toast.LENGTH_SHORT).show();
            }
        });

        mRightNavigationButtonHandler = new RightNavigationButtonHandler(webViewBridge, text_title_right);
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_SET_NAVBAR_RIGHT_BTN, mRightNavigationButtonHandler);

        mContactHistoryHandler = new ContactHistoryHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_CALL_HISTORY, mContactHistoryHandler);

        mSMSHandler = new SMSHandler();
        webViewBridge.registerHandler(WebUrlUtil.BRIDGE_KEY_GET_SMS_HISTORY, mSMSHandler);

    }


    private void initListener() {
        fab_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (null != web_content && !web_content.canGoBack()) {
                    Snackbar.make(v, "确定要退出吗?", Snackbar.LENGTH_LONG)
                            .setAction("退出", new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    onBackPressed();
                                }
                            }).show();
                } else {
                    onBackPressed();
                }
            }
        });

        this.image_web_choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                image_web_choose.setVisibility(View.GONE);
            }
        });

    }


    @Override
    public void bindHandler(BridgeHandler handler) {
        mPhotoHandler = handler;
    }

    @Override
    public void activityForResult(Intent intent, int requestCode) {
        startActivityForResult(intent, requestCode);
    }

    @Override
    public Activity getActivity() {
        return this;
    }

    private class MyWebViewCallBack implements IWebViewCallBack {

        @Override
        public boolean loadUrl(WebView webView, String url) {
            //解密接口
            url = WebUrlUtil.getNewUrl(url);
            //第三方URL 处理
            if (!WebUrlUtil.usrByThird(webViewBridge, url)) {
                if (null != mRightNavigationButtonHandler) {
                    mRightNavigationButtonHandler.showNavigationBar(null);
                }
                webView.loadUrl(url);
            }
            return true;
        }

        @Override
        public void setTitle(String title) {
            WebViewActivity.this.setTitle(title);
        }

        @Override
        public void loadProgress(int gone, int progress) {
            progress_bar_web.setProgress(progress);
            progress_bar_web.setVisibility(gone);
        }

        @Override
        public void error(int errorCode, String description, String failingUrl) {
            Toast.makeText(WebViewActivity.this, description, Toast.LENGTH_SHORT).show();
        }

        /**
         * 嵌入JS
         *
         * @param view
         */
        @Override
        public void injectJS(WebView view) {
            if (WebViewBridge.toLoadJs != null) {
                BridgeUtil.webViewLoadLocalJs(view, WebViewBridge.toLoadJs);
            }
            if (null != webViewBridge.getStartupMessage()) {
                if (null != webViewBridge.getStartupMessage() && webViewBridge.getStartupMessage().size() > 0) {
                    for (BridgeMessage message : webViewBridge.getStartupMessage()) {
                        webViewBridge.dispatchMessage(message);
                    }
                }
                webViewBridge.setStartupMessage(null);
            }
        }

    }


    /**
     * 跳转至当前应用的设置界面
     */
    private void enterSetting() {
        Intent localIntent = new Intent();
        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        localIntent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
        localIntent.setData(Uri.fromParts("package", getPackageName(), null));
        startActivity(localIntent);
    }


    /**
     * 权限检查回调
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (!PermissionUtil.getInstance().onRequestPermissionsResult(grantResults)) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("请开启相关权限，以便实现相应功能");
            builder.setPositiveButton("开启", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    enterSetting();

                }
            });
            builder.create().show();
            return;
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_LOCATION, grantResults)) {
            mLocationHandler.initLocation();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_CHOOSE, grantResults)) {
            mChooseImageHandler.getCameraImage();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_CAMERA, grantResults)) {
            ((PhotoHandler) mPhotoHandler).getCameraImage();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_STORAGE, grantResults)) {
            mPreviewImageHandler.showImage();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_CONTACT, grantResults)) {
            mContactHandler.readContact();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_CONTACT_ALL, grantResults)) {
            mAllContactHandler.readContact();
        }
        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_SMS, grantResults)) {
            mSMSHandler.getSMSData();
        }

        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_CONTACT_HISTORY, grantResults)) {
            mContactHistoryHandler.readContactHistory();
        }

        if (PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_PHONE, grantResults)) {
            sendDeviceInfo(true);
        } else if (!PermissionUtil.getInstance().onRequestPermissionsResult(DefaultHandler.REQUEST_CODE_PERMISSION_PHONE, grantResults)) {
            sendDeviceInfo(false);
        }


        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    /**
     * 拍照回调
     *
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {
            return;
        }
        if (requestCode == DefaultHandler.REQUEST_CODE_LOCATION) {
            mLocationHandler.onActivityResult(requestCode, resultCode, data);
        }
        if (requestCode == DefaultHandler.REQUEST_CODE_CHOOSE_CAMERA || requestCode == DefaultHandler.REQUEST_CODE_CHOOSE_ALBUM) {
            mChooseImageHandler.onActivityResult(requestCode, resultCode, data);
        }
        if (requestCode == DefaultHandler.REQUEST_CODE_CAMERA) {
            mPhotoHandler.onActivityResult(requestCode, resultCode, data);
        }
        if (requestCode == DefaultHandler.REQUEST_CODE_CONTACT) {
            mContactHandler.onActivityResult(requestCode, resultCode, data);
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    private void sendDeviceInfo(boolean ok) {
        if (null == phoneFunction) {
            return;
        }
        if (!ok) {
            phoneFunction.onCallBack(new RequestDeviceInfo(RequestBase.GET_DATA_FAIL, "权限获取失败").toJson());
        } else {
            phoneFunction.onCallBack(new RequestDeviceInfo(AppUtil.getDeviceInfo(this)).toJson());
        }

    }

}
