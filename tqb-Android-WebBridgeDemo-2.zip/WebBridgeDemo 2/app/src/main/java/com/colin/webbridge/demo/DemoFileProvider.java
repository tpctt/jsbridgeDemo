package com.colin.webbridge.demo;

import android.support.v4.content.FileProvider;

/**
 * Created by hbl on 2017/4/26.
 */

public class DemoFileProvider extends FileProvider {

}
