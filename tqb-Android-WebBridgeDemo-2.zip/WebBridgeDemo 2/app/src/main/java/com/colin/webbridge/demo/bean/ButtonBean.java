package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/8/11.
 */

public class ButtonBean extends Object {
    private String frontColor ;
    private String title ;
    private String activePath ;


    public String getFrontColor() {
        return frontColor;
    }

    public ButtonBean setFrontColor(String frontColor) {
        this.frontColor = frontColor;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public ButtonBean setTitle(String title) {
        this.title = title;
        return this;
    }

    public String getActivePath() {
        return activePath;
    }

    public ButtonBean setActivePath(String activePath) {
        this.activePath = activePath;
        return this;
    }
}
