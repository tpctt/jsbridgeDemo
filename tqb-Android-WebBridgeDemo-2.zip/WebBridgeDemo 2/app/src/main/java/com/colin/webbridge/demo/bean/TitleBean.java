package com.colin.webbridge.demo.bean;

/**
 * Created by Administrator on 2017/7/21.
 */

public class TitleBean {
    public String title ;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
