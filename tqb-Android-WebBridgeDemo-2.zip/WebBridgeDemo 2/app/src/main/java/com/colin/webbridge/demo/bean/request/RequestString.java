package com.colin.webbridge.demo.bean.request;


/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestString extends RequestBase {

    private String data;

    public RequestString(int code) {
        super(code);
    }

    public RequestString(String data) {
        this.data = data ;
    }

    public RequestString(int code, String msg) {
        super(code, msg);
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
