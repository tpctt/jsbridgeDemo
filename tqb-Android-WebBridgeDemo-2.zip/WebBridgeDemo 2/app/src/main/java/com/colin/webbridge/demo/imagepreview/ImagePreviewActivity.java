package com.colin.webbridge.demo.imagepreview;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.TextView;

import com.colin.webbridge.demo.R;

import java.util.ArrayList;


public class ImagePreviewActivity extends AppCompatActivity  {
    public static final int ANIMATE_DURATION = 200;

    private MyViewPager pager_image_preview;
    private TextView text_image_preview_current;

    private ImagePreviewAdapter imagePreviewAdapter;
    private ArrayList<String> mImageInfoList;
    private boolean fromNet = true;//默认显示图片来源网络端
    private int currentItem;
    private String id;
    private String userName;
    private String message;
    private int grade;
    private int support;
    private int voted;
    private int commentState = 2;
    private int imageHeight;
    private int imageWidth;
    private int screenWidth;
    private int screenHeight;
    private boolean httpNeting = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_preview);
        initView();
    }

    @Override
    protected void onDestroy() {
        if (null != mImageInfoList) {
            mImageInfoList.clear();
            mImageInfoList = null;
        }
        imagePreviewAdapter = null;
        httpNeting = false;
        super.onDestroy();
    }

    private void initView() {
        pager_image_preview = (MyViewPager) this.findViewById(R.id.pager_image_preview);
        text_image_preview_current = (TextView) this.findViewById(R.id.text_image_preview_current);
        Bundle bundle = getIntent().getExtras();
        if (null != bundle) {
            currentItem = bundle.getInt("currentItem", 0);
            mImageInfoList = bundle.getStringArrayList("list");
        }
        initViewPager();
    }

    private void initViewPager() {
        if (null == mImageInfoList) {
            mImageInfoList = new ArrayList<String>();
        }
        if (null == imagePreviewAdapter) {
            imagePreviewAdapter = new ImagePreviewAdapter(this, mImageInfoList);
        }
        pager_image_preview.setAdapter(imagePreviewAdapter);
        pager_image_preview.setCurrentItem(currentItem);
        pager_image_preview.setOffscreenPageLimit(mImageInfoList.size());
        pager_image_preview.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                currentItem = position;
                setPage();
            }
        });
        setPage();
    }

    /**
     * 显示页码
     */
    private void setPage() {
        text_image_preview_current.setText(String.valueOf(currentItem + 1) + "/" + String.valueOf(mImageInfoList.size()));
    }

}
