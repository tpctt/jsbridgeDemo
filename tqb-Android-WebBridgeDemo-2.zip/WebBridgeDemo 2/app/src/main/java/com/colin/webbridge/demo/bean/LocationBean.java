package com.colin.webbridge.demo.bean;

import android.location.Location;

/**
 * Created by Administrator on 2017/7/21.
 */

public class LocationBean extends Object {
    private double latitude = 0.0D;
    private double longitude = 0.0D;
    private String address; //四川省成都市武侯区天府大道3段1099号
    private AddressDetail addressDetail;

    public LocationBean(Location location) {
        this.latitude = location.getLatitude();
        this.longitude = location.getLongitude();
        this.address = location.getExtras().toString();
        addressDetail = new AddressDetail();
        addressDetail.province = location.getProvider();
        addressDetail.city = location.getProvider();
        addressDetail.region = location.getProvider();
        addressDetail.street = location.getProvider();
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public static class AddressDetail {
        private String province;  //四川省
        private String city;//成都市
        private String region;//武侯区
        private String street;//天府大道
    }
}
