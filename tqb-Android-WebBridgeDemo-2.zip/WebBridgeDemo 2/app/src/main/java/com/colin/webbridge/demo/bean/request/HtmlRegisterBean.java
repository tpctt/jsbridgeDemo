package com.colin.webbridge.demo.bean.request;

/**
 * Created by Administrator on 2017/8/8.
 */

public class HtmlRegisterBean extends Object {
    public String idenify;
}
