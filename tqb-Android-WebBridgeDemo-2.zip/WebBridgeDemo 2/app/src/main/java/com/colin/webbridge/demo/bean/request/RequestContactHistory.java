package com.colin.webbridge.demo.bean.request;


import com.colin.webbridge.demo.bean.ContactHistoryBean;

import java.util.List;

/**
 * Created by Administrator on 2017/7/21.
 */

public class RequestContactHistory extends RequestBase {

    private List<ContactHistoryBean> data;

    public RequestContactHistory(int code) {
        super(code);
    }

    public RequestContactHistory(List<ContactHistoryBean> data) {
        this.data = data ;
    }

    public RequestContactHistory(int code, String msg) {
        super(code, msg);
    }

    public List<ContactHistoryBean> getData() {
        return data;
    }

    public void setData(List<ContactHistoryBean> data) {
        this.data = data;
    }

    @Override
    public String toString() {
        return "RequestContact{" +
                "data=" + data +
                '}';
    }
}
