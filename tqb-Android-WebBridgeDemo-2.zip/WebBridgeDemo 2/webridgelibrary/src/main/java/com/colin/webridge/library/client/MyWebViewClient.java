package com.colin.webridge.library.client;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.colin.webridge.library.callback.IWebViewCallBack;

/**
 * Created by Administrator on 2017/7/18.
 */
@SuppressLint("SetJavaScriptEnabled")
public class MyWebViewClient extends WebViewClient {
    private IWebViewCallBack mIWebViewCallBack;

    public MyWebViewClient() {
    }

    public MyWebViewClient(IWebViewCallBack IWebViewCallBack) {
        mIWebViewCallBack = IWebViewCallBack;
    }

    // url拦截
    @Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (null == mIWebViewCallBack || !mIWebViewCallBack.loadUrl(view, url)) {
            view.loadUrl(url);
        }
        return true;
    }

    // 页面开始加载
    @Override
    public void onPageStarted(WebView webView, String url, Bitmap favicon) {
        webView.getSettings().setJavaScriptEnabled(true);
        super.onPageStarted(webView, url, favicon);
        if (null != mIWebViewCallBack) {
            mIWebViewCallBack.loadProgress(View.VISIBLE, 0);
        }
    }

    // 页面加载完成
    @Override
    public void onPageFinished(WebView webView, String url) {
        if (null != mIWebViewCallBack) {
            mIWebViewCallBack.loadProgress(View.GONE, 100);
            //嵌入JS
            mIWebViewCallBack.injectJS(webView);
        }
        super.onPageFinished(webView, url);
        webView.setVisibility(View.VISIBLE);
        webView.invalidate();


    }

    // WebView加载的所有资源url
    @Override
    public void onLoadResource(WebView view, String url) {
        super.onLoadResource(view, url);
    }

    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        super.onReceivedError(view, errorCode, description, failingUrl);
        if (null != mIWebViewCallBack) {
            mIWebViewCallBack.loadProgress(View.GONE, 100);
            mIWebViewCallBack.error(errorCode, description, failingUrl);
        }
    }


    private String onPageError(String s) {
        return s;
    }

}
