package com.colin.webridge.library.callback;

import android.app.Activity;
import android.content.Intent;

import com.colin.webridge.library.handler.BridgeHandler;

/**
 * Created by hbl on 2017/5/11.
 */

public interface BridgeInterface {
    void bindHandler(BridgeHandler handler);

    void activityForResult(Intent intent, int requestCode);

    Activity getActivity();

}
