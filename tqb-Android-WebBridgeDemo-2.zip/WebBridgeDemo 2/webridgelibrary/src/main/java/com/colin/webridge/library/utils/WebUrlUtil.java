package com.colin.webridge.library.utils;

import android.text.TextUtils;

import com.colin.webridge.library.WebViewBridge;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

/**
 * Created by Administrator on 2017/7/18.
 */

public class WebUrlUtil {
    //注册事件关键词
    public static final String BRIDGE_KEY_GET_LOCATION = "getLocation";//定位
    public static final String BRIDGE_KEY_GET_TOKEN = "getToken";//获取Token
    public static final String BRIDGE_KEY_CHOOSE_IMAGE = "chooseImage";//选择图片，上传一张图片base64加密之后的数据
    public static final String BRIDGE_KEY_PREVIEW_IMAGE = "previewImage";//阅览图片
    public static final String BRIDGE_KEY_MAKE_PHONE_CALL = "makePhoneCall";//打电话
    public static final String BRIDGE_KEY_SET_CLIPBOARD_DATA = "setClipboardData";//HTML中获取的值赋值到Android手机中的剪切板中
    public static final String BRIDGE_KEY_GET_CLIPBOARD_DATA = "getClipboardData";//把Android手机剪切板中的数据传给HTML
    public static final String BRIDGE_KEY_SET_NAVIGATION_BAR_TITLE = "setNavigationBarTitle";//设置标题
    public static final String BRIDGE_KEY_SET_NAVIGATION_BAR_COLOR = "setNavigationBarColor";//设置系统导航栏的颜色
    public static final String BRIDGE_KEY_SHOW_NAVIGATION_BAR = "showNavigationBar";//显示系统导航栏
    public static final String BRIDGE_KEY_HIDE_NAVIGATION_BAR = "hideNavigationBar";//隐藏系统导航栏
    public static final String BRIDGE_KEY_NAVIGATE_TO = "navigateTo";//保留当前页面，跳转到应用内的某个页面，使用tqb.navigateBack可以返回到原页面。
    public static final String BRIDGE_KEY_REDIRECT_TO = "redirectTo";//关闭当前页面，跳转到应用内的某个页面。
    public static final String BRIDGE_KEY_NAVIGATE_BACK = "navigateBack";//返回
    public static final String BRIDGE_KEY_GET_CONTACT = "getContact";//获取单个通讯录内容
    public static final String BRIDGE_KEY_GET_ADDRESS_BOOK = "getAddressBook";//获取手机通讯录全部内容
    //待定。。。。
    public static final String BRIDGE_KEY_JS_PROXY_VER = "jsProxyVer";//上传版本信息
    public static final String BRIDGE_KEY_LOGIN = "login";//登录
    public static final String BRIDGE_KEY_LOGOUT = "logout";//退出登录
    public static final String BRIDGE_KEY_SHARE_INFO = "shareInfo";//分享
    public static final String BRIDGE_KEY_GET_DEVICE_INFO = "getDeviceInfo";//获取设备相关信息
    public static final String BRIDGE_KEY_GET_USER_INFO = "getUserInfo";//获取用户信息
    public static final String BRIDGE_KEY_GET_APP_VERSION_DATA = "getAppVersionData";//获取app版本信息
    public static final String BRIDGE_KEY_REGISTER = "register";//注册
    public static final String BRIDGE_KEY_SET_NAVBAR_RIGHT_BTN = "setNavbarRightBtn";//标题栏右上角菜单按钮设置
    public static final String BRIDGE_KEY_SET_NAVBAR_RIGHT_BTN_TWO = "setNavbarRightBtn2";//标题栏右上角菜单按钮设置
    public static final String BRIDGE_KEY_GET_CALL_HISTORY = "getCallHistory";//电话历史记录
    public static final String BRIDGE_KEY_GET_SMS_HISTORY = "getSmsHistory";//短信历史记录


    public static boolean startsWith(String url, String startWith) {
        return false;
    }

    /**
     * 对于URL 解密
     *
     * @param url
     * @return
     */
    public static String getNewUrl(String url) {
        try {
            url = URLDecoder.decode(url, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            LogUtil.e("url-->>" + url);
            e.printStackTrace();
        }
        return url;
    }

    /**
     * 第三方 是否需要独立处理的接口
     *
     * @param webViewBridge
     * @param url
     * @return
     */
    public static boolean usrByThird(WebViewBridge webViewBridge, String url) {
        //gome 第三方处理
        if (null != webViewBridge && null != url && !TextUtils.isEmpty(url)) {
            if (url.indexOf("tel:") == 0) {
                return true;
            }
            if (url.startsWith(BridgeUtil.RETURN_DATA)) { // 如果是返回数据
                webViewBridge.handlerReturnData(url);
                return true;
            } else if (url.startsWith(BridgeUtil.OVERRIDE_SCHEMA)) { //
                webViewBridge.flushMessageQueue();
                return true;
            }
        }
        return false;
    }
}
