package com.colin.webridge.library.handler;

import android.content.Intent;
import android.support.annotation.NonNull;

import com.colin.webridge.library.callback.BridgeInterface;
import com.colin.webridge.library.callback.CallBackFunction;

public interface BridgeHandler {

    void handler(String data, CallBackFunction function, BridgeInterface bridgeInterface);

    void onActivityResult(int requestCode, int resultCode, Intent data);

    void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) ;
}
