package com.colin.webridge.library.handler;

import android.content.Intent;
import android.support.annotation.NonNull;

/**
 * Created by hbl on 2017/5/11.
 */

public abstract class DefaultHandler implements BridgeHandler {
    public final static int REQUEST_CODE_LOCATION = 0;
    public final static int REQUEST_CODE_CHOOSE_CAMERA = 1;
    public final static int REQUEST_CODE_CHOOSE_ALBUM = 2;
    public final static int REQUEST_CODE_CAMERA = 3;
    public final static int REQUEST_CODE_CONTACT = 4;
    public final static int REQUEST_CODE_PERMISSION_LOCATION = 0;
    public final static int REQUEST_CODE_PERMISSION_CHOOSE = 1;
    public final static int REQUEST_CODE_PERMISSION_CAMERA = 2;
    public final static int REQUEST_CODE_PERMISSION_STORAGE = 3;
    public final static int REQUEST_CODE_PERMISSION_CONTACT = 4;
    public final static int REQUEST_CODE_PERMISSION_CONTACT_ALL = 5;
    public final static int REQUEST_CODE_PERMISSION_CONTACT_HISTORY = 6;
    public final static int REQUEST_CODE_PERMISSION_PHONE= 7;
    public final static int REQUEST_CODE_PERMISSION_SMS= 8;
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

    }
}
