package com.colin.webridge.library.callback;

public interface CallBackFunction {

    void onCallBack(String data);

}
