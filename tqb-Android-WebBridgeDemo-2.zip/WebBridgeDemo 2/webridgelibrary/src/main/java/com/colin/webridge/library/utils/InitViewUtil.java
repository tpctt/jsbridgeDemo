package com.colin.webridge.library.utils;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.widget.SwipeRefreshLayout;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.colin.webridge.library.R;
import com.colin.webridge.library.callback.IWebViewCallBack;
import com.colin.webridge.library.client.MyWebChromeClient;
import com.colin.webridge.library.client.MyWebViewClient;

/**
 * 初始化控件
 */

public class InitViewUtil {
    public static void initSwipeRefreshLayout(SwipeRefreshLayout swipeRefreshLayout) {
        swipeRefreshLayout.setProgressBackgroundColorSchemeColor(swipeRefreshLayout.getContext().getResources().getColor(R.color.colorPrimary));

        swipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);
    }

    @SuppressLint("SetJavaScriptEnabled")
    public static void initWebView(WebView webView, String url, IWebViewCallBack iWebViewCallBack) {
        // 设置支持JavaScript脚本
        WebSettings webSettings = webView.getSettings();
        webSettings.setDefaultTextEncodingName("UTF-8");
        webSettings.setJavaScriptEnabled(true);// 设置可以运行JS脚本
        // 设置可以访问文件
        webSettings.setAllowFileAccess(true);
        // 设置可以支持缩放
        webSettings.setSupportZoom(false);
        // 设置默认缩放方式尺寸是far
        webSettings.setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);
        // 设置出现缩放工具
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDefaultFontSize(20);
        // 允许js弹出窗口
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);


        webSettings.setUseWideViewPort(true);// 打开页面时， 自适应屏幕
        webSettings.setLoadWithOverviewMode(true);// 打开页面时， 自适应屏幕
        // webSettings.setTextZoom(120);//Sets the text zoom of the page in
        // percent. The default is 100.
        webSettings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.SINGLE_COLUMN);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        // 判断系统版本是不是5.0或之上
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            //让系统不屏蔽混合内容
            webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

//        webView.setBackgroundResource(R.color.transparent);
        webView.setBackgroundColor(Color.parseColor("#00000000"));
//        webview_framgnet_mall.loadUrl(url);// 加载网址
        // 添加js交互接口类，并起别名 imagelistner
        webView.setWebViewClient(new MyWebViewClient(iWebViewCallBack));
        webView.setWebChromeClient(new MyWebChromeClient(iWebViewCallBack));
        webView.loadUrl(url);
    }


}
