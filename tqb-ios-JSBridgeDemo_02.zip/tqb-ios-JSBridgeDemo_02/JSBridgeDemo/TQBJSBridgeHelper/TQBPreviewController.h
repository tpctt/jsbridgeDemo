//
//  TQBPreviewController.h
//  JSBridgeDemo
//
//  Created by Zhang Wuyang on 2017/7/20.
//  Copyright © 2017年 gomeguomingyue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TQBPreviewController : UIViewController

@property (nonatomic, strong) NSArray * imageArray;


@end
