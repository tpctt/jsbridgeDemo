//
//  SXPersonInfoEntity.h
//  SXEasyAddressBookDemo
//
//  Created by dongshangxian on 16/5/23.
//  Copyright © 2016年 Sankuai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SXPersonInfoEntity : NSObject

@property(nonatomic,copy)NSString *firstname;
@property(nonatomic,copy)NSString *lastname;
@property(nonatomic,copy)NSString *fullname;
@property(nonatomic,copy)NSString *company;
@property(nonatomic,copy)NSString *phoneNumber;

@end
