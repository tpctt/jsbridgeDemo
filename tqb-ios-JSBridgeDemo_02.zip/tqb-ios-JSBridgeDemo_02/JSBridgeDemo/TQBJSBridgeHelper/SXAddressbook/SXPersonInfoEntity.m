//
//  SXPersonInfoEntity.m
//  SXEasyAddressBookDemo
//
//  Created by dongshangxian on 16/5/23.
//  Copyright © 2016年 Sankuai. All rights reserved.
//

#import "SXPersonInfoEntity.h"

@implementation SXPersonInfoEntity

@end
