//
//  AppDelegate.h
//  JSBridgeDemo
//
//  Created by gomeguomingyue on 2017/4/27.
//  Copyright © 2017年 gomeguomingyue. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@property (nonatomic, strong) UINavigationController * navi;


@end

