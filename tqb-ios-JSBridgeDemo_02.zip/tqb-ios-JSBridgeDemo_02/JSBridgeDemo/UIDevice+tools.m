//
//  tools.m
//  taoqianbao
//
//  Created by tim on 17/1/3.
//  Copyright © 2017年 tim. All rights reserved.
//

#import "UIDevice+tools.h"
///freeDiskSpaceInMB
#include <sys/mount.h>
#include <sys/param.h>
#include <sys/sysctl.h>

//PLAT
#include <mach/host_info.h>
#include <mach/mach_host.h>

//SSID
#import <SystemConfiguration/CaptiveNetwork.h>
#import <SystemConfiguration/SystemConfiguration.h>


//MAC
#include <sys/socket.h> // Per msqr
#include <sys/sysctl.h>
#include <net/if.h>
#include <net/if_dl.h>

///SIM
#import <SystemConfiguration/CaptiveNetwork.h>
#import <CoreTelephony/CTTelephonyNetworkInfo.h>
#import <CoreTelephony/CTCarrier.h>

#import <AddressBook/AddressBook.h>
#import <AddressBook/ABRecord.h>
#import <AddressBook/ABPerson.h>

@implementation UIDevice(tools)

+(NSString *)freeDiskSpaceInMB
{
    struct statfs buf;
    long long freespace = -1;
    if(statfs("/var", &buf) >= 0){
        freespace = (long long)(buf.f_bsize * buf.f_bfree);
    }
    //    return [NSString stringWithFormat:@"手机剩余存储空间为：%qi MB" ,freespace/1024/1024];
    return [NSString stringWithFormat:@"%qi" ,freespace/1024/1024];
    
}

+(NSString*)getCPUTypeString
{
    host_basic_info_data_t hostInfo;
    mach_msg_type_number_t infoCount;
    
    infoCount = HOST_BASIC_INFO_COUNT;
    host_info(mach_host_self(), HOST_BASIC_INFO, (host_info_t)&hostInfo, &infoCount);
    
    NSString *typeString;
    switch (hostInfo.cpu_type) {
        case CPU_TYPE_ARM:
            NSLog(@"CPU_TYPE_ARM");
            typeString = @"CPU_TYPE_ARM";
            break;
            
        case CPU_TYPE_ARM64:
            NSLog(@"CPU_TYPE_ARM64");
            typeString = @"CPU_TYPE_ARM64";

            break;
            
        case CPU_TYPE_X86:
            NSLog(@"CPU_TYPE_X86");
            typeString = @"CPU_TYPE_X86";

            break;
            
        case CPU_TYPE_X86_64:
            NSLog(@"CPU_TYPE_X86_64");
            typeString = @"CPU_TYPE_X86_64";

            break;
            
        default:
            break;
    }
    
    return typeString;
}


+(NSString *)platformString{
    // Gets a string with the device model
    size_t size;
    sysctlbyname("hw.machine", NULL, &size, NULL, 0);
    char *machine = malloc(size);
    sysctlbyname("hw.machine", machine, &size, NULL, 0);
    NSString *platform = [NSString stringWithCString:machine encoding:NSUTF8StringEncoding];
    free(machine);
    if ([platform isEqualToString:@"iPhone1,1"])    return @"iPhone 2G";
    if ([platform isEqualToString:@"iPhone1,2"])    return @"iPhone 3G";
    if ([platform isEqualToString:@"iPhone2,1"])    return @"iPhone 3GS";
    if ([platform isEqualToString:@"iPhone3,1"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,2"])    return @"iPhone 4";
    if ([platform isEqualToString:@"iPhone3,3"])    return @"iPhone 4 (CDMA)";
    if ([platform isEqualToString:@"iPhone4,1"])    return @"iPhone 4S";
    if ([platform isEqualToString:@"iPhone5,1"])    return @"iPhone 5";
    if ([platform isEqualToString:@"iPhone5,2"])    return @"iPhone 5 (GSM+CDMA)";
    
    if ([platform isEqualToString:@"iPod1,1"])      return @"iPod Touch (1 Gen)";
    if ([platform isEqualToString:@"iPod2,1"])      return @"iPod Touch (2 Gen)";
    if ([platform isEqualToString:@"iPod3,1"])      return @"iPod Touch (3 Gen)";
    if ([platform isEqualToString:@"iPod4,1"])      return @"iPod Touch (4 Gen)";
    if ([platform isEqualToString:@"iPod5,1"])      return @"iPod Touch (5 Gen)";
    
    if ([platform isEqualToString:@"iPad1,1"])      return @"iPad";
    if ([platform isEqualToString:@"iPad1,2"])      return @"iPad 3G";
    if ([platform isEqualToString:@"iPad2,1"])      return @"iPad 2 (WiFi)";
    if ([platform isEqualToString:@"iPad2,2"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,3"])      return @"iPad 2 (CDMA)";
    if ([platform isEqualToString:@"iPad2,4"])      return @"iPad 2";
    if ([platform isEqualToString:@"iPad2,5"])      return @"iPad Mini (WiFi)";
    if ([platform isEqualToString:@"iPad2,6"])      return @"iPad Mini";
    if ([platform isEqualToString:@"iPad2,7"])      return @"iPad Mini (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,1"])      return @"iPad 3 (WiFi)";
    if ([platform isEqualToString:@"iPad3,2"])      return @"iPad 3 (GSM+CDMA)";
    if ([platform isEqualToString:@"iPad3,3"])      return @"iPad 3";
    if ([platform isEqualToString:@"iPad3,4"])      return @"iPad 4 (WiFi)";
    if ([platform isEqualToString:@"iPad3,5"])      return @"iPad 4";
    if ([platform isEqualToString:@"iPad3,6"])      return @"iPad 4 (GSM+CDMA)";
    
    if ([platform isEqualToString:@"i386"])         return @"Simulator";
    if ([platform isEqualToString:@"x86_64"])       return @"Simulator";
    return platform;
}

///WIFI SSID
+ (NSString *)getDeviceSSID
{
    NSArray *ifs = (__bridge_transfer id)CNCopySupportedInterfaces();
    
    id info = nil;
    for (NSString *ifnam in ifs) {
        info = (__bridge_transfer id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        if (info && [info count]) {
            break;
        }
    }
    NSDictionary *dctySSID = (NSDictionary *)info;
    NSString *ssid = [[dctySSID objectForKey:@"SSID"] lowercaseString];
    
    return ssid;
    
}
+ (NSString *)getDeviceBSSID
{
    NSArray *ifs = (__bridge_transfer id)CNCopySupportedInterfaces();
    
    id info = nil;
    for (NSString *ifnam in ifs) {
        info = (__bridge_transfer id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        if (info && [info count]) {
            break;
        }
    }
    NSDictionary *dctySSID = (NSDictionary *)info;
    NSString *ssid = [[dctySSID objectForKey:@"BSSID"] lowercaseString];
    
    return ssid;
    
}


+ (NSString *) getMacAddress
{
    int mib[6];
    
    size_t len;
    
    char *buf;
    
    unsigned char *ptr;
    
    struct if_msghdr *ifm;
    
    struct sockaddr_dl *sdl;
    
    
    mib[0] = CTL_NET;
    
    mib[1] = AF_ROUTE;
    
    mib[2] = 0;
    
    mib[3] = AF_LINK;
    
    mib[4] = NET_RT_IFLIST;
    
    
    if ((mib[5] = if_nametoindex("en0")) == 0) {
        
        printf("Error: if_nametoindex error/n");
        
        return NULL;
        
    }
    
    
    if (sysctl(mib, 6, NULL, &len, NULL, 0) < 0) {
        
        printf("Error: sysctl, take 1/n");
        
        return NULL;
        
    }
    
    if ((buf = malloc(len)) == NULL) {
        
        printf("Could not allocate memory. error!/n");
        
        return NULL;
        
    }
    
    
    
    if (sysctl(mib, 6, buf, &len, NULL, 0) < 0) {
        
        printf("Error: sysctl, take 2");
        
        return NULL;
        
    }
    
    
    ifm = (struct if_msghdr *)buf;
    
    sdl = (struct sockaddr_dl *)(ifm + 1);
    
    ptr = (unsigned char *)LLADDR(sdl);
    
    NSString *outstring = [NSString stringWithFormat:@"%02x:%02x:%02x:%02x:%02x:%02x", *ptr, *(ptr+1), *(ptr+2), *(ptr+3), *(ptr+4), *(ptr+5)];
    
    free(buf);
    
    return [outstring uppercaseString];
    
}


+(NSString *)getSIMcarrier
{
    
    CTTelephonyNetworkInfo *networkInfo = [[CTTelephonyNetworkInfo alloc] init];
    
    CTCarrier *carrier = networkInfo.subscriberCellularProvider;
    
    
    return carrier.carrierName;
    
//    NSString *carrier_country_code = carrier.isoCountryCode;
//    
//    if (carrier_country_code == nil) {
//        
//        carrier_country_code = @"";
//        
//    }
//    
//    //国家编号
//    
//    NSString *CountryCode = carrier.mobileCountryCode;
//    
//    if (CountryCode == nil) {
//        
//        CountryCode = @"";
//        
//    }
//    
//    //网络供应商编码
//    
//    NSString *NetworkCode = carrier.mobileNetworkCode;
//    
//    if (NetworkCode == nil)
//        
//    {
//        
//        NetworkCode = @"";
//        
//    }
//    
//    
//    
//    NSString *mobile_country_code = [NSString stringWithFormat:@"%@%@",CountryCode,NetworkCode];
//    
//    if (mobile_country_code == nil)
//        
//    {
//        
//        mobile_country_code = @"";
//        
//    }
//    
//    
//    
//    NSString *carrier_name = nil;    //网络运营商的名字
//    
//    NSString *code = [carrier mobileNetworkCode];
//    
//    
//    
//    if ([code isEqualToString:@"00"] || [code isEqualToString:@"02"] || [code isEqualToString:@"07"]) {
//        
//        //移动
//        
//        carrier_name = @"CMCC";
//        
//    }
//    
//    
//    
//    if ([code isEqualToString:@"03"] || [code isEqualToString:@"05"])
//        
//    {
//        
//        // ret = @"电信";
//        
//        carrier_name =  @"CTCC";
//        
//    }
//    
//    
//    
//    if ([code isEqualToString:@"01"] || [code isEqualToString:@"06"])
//        
//    {
//        
//        // ret = @"联通";
//        
//        carrier_name =  @"CUCC";
//        
//    }
//    
//    
//    
//    if (code == nil)
//        
//    {
//        
//        carrier_name = @"";
//        
//    }
//    
//    
//    
//    carrier_name = [[NSString stringWithFormat:@"%@-%@",carrier_name,carrier.carrierName] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
//    
//    return carrier_name;
    
}

//2/3/4g
+(NSString*)getNetWorkType
{
    NSString *strNetworkType = @"";
    
    //创建零地址，0.0.0.0的地址表示查询本机的网络连接状态
    struct sockaddr_storage zeroAddress;
    
    bzero(&zeroAddress, sizeof(zeroAddress));
    zeroAddress.ss_len = sizeof(zeroAddress);
    zeroAddress.ss_family = AF_INET;
    
    // Recover reachability flags
    SCNetworkReachabilityRef defaultRouteReachability = SCNetworkReachabilityCreateWithAddress(NULL, (struct sockaddr *)&zeroAddress);
    SCNetworkReachabilityFlags flags;
    
    //获得连接的标志
    BOOL didRetrieveFlags = SCNetworkReachabilityGetFlags(defaultRouteReachability, &flags);
    CFRelease(defaultRouteReachability);
    
    //如果不能获取连接标志，则不能连接网络，直接返回
    if (!didRetrieveFlags)
    {
        return strNetworkType;
    }
    
    
    if ((flags & kSCNetworkReachabilityFlagsConnectionRequired) == 0)
    {
        // if target host is reachable and no connection is required
        // then we'll assume (for now) that your on Wi-Fi
        strNetworkType = @"WIFI";
    }
    
    if (
        ((flags & kSCNetworkReachabilityFlagsConnectionOnDemand ) != 0) ||
        (flags & kSCNetworkReachabilityFlagsConnectionOnTraffic) != 0
        )
    {
        // ... and the connection is on-demand (or on-traffic) if the
        // calling application is using the CFSocketStream or higher APIs
        if ((flags & kSCNetworkReachabilityFlagsInterventionRequired) == 0)
        {
            // ... and no [user] intervention is needed
            strNetworkType = @"WIFI";
        }
    }
    
    if ((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
    {
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
        {
            CTTelephonyNetworkInfo * info = [[CTTelephonyNetworkInfo alloc] init];
            NSString *currentRadioAccessTechnology = info.currentRadioAccessTechnology;
            
            if (currentRadioAccessTechnology)
            {
                if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyLTE])
                {
                    strNetworkType =  @"4G";
                }
                else if ([currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyEdge] || [currentRadioAccessTechnology isEqualToString:CTRadioAccessTechnologyGPRS])
                {
                    strNetworkType =  @"2G";
                }
                else
                {
                    strNetworkType =  @"3G";
                }
            }
        }
        else
        {
            if((flags & kSCNetworkReachabilityFlagsReachable) == kSCNetworkReachabilityFlagsReachable)
            {
                if ((flags & kSCNetworkReachabilityFlagsTransientConnection) == kSCNetworkReachabilityFlagsTransientConnection)
                {
                    if((flags & kSCNetworkReachabilityFlagsConnectionRequired) == kSCNetworkReachabilityFlagsConnectionRequired)
                    {
                        strNetworkType = @"2G";
                    }
                    else
                    {
                        strNetworkType = @"3G";
                    }
                }
            }
        }
    }
    
    
    if ([strNetworkType isEqualToString: @""]) {
        strNetworkType = @"WWAN";
    }
    
//    NSLog( @"GetNetWorkType() strNetworkType :  %s", strNetworkType.c_str());
    
    return strNetworkType;
}

+ (nullable NSArray *)loadPerson
{
//    ABAddressBookRef addressBookRef = ABAddressBookCreateWithOptions(NULL, NULL);
    
    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined) {
        //        ABAddressBookRequestAccessWithCompletion(addressBookRef, ^(bool granted, CFErrorRef error){
        //
        //            CFErrorRef *error1 = NULL;
        //            ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error1);
        //            [self copyAddressBook:addressBook];
        //        });
    }
    else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized){
        
        CFErrorRef *error = NULL;
        ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, error);
        return [self copyAddressBook:addressBook];
    }
    else {
        //        dispatch_async(dispatch_get_main_queue(), ^{
        //            // 更新界面
        ////            [hud turnToError:@"没有获取通讯录权限"];
        //        });
    }
    return nil ;
}
+ (nullable NSArray *)copyAddressBook:(ABAddressBookRef)addressBook
{
    
    NSMutableArray *array = [NSMutableArray array ];
    
    
    
    CFIndex numberOfPeople = ABAddressBookGetPersonCount(addressBook);
    CFArrayRef people = ABAddressBookCopyArrayOfAllPeople(addressBook);
    
    for ( int i = 0; i < numberOfPeople; i++){
        
        NSMutableDictionary *personInfo = [NSMutableDictionary dictionary];
        
        
        
        ABRecordRef person = CFArrayGetValueAtIndex(people, i);
        
//        ABMultiValueRef dic =ABMultiValueCreateMutable(kABMultiStringPropertyType);
        
        NSString *firstName = (__bridge_transfer NSString *)(ABRecordCopyValue(person, kABPersonFirstNameProperty));
        NSString *lastName = (__bridge_transfer NSString *)(ABRecordCopyValue(person, kABPersonLastNameProperty));
        
        //读取middlename
//        NSString *middlename = (__bridge NSString*)ABRecordCopyValue(person, kABPersonMiddleNameProperty);
//        //读取prefix前缀
//        NSString *prefix = (__bridge NSString*)ABRecordCopyValue(person, kABPersonPrefixProperty);
//        //读取suffix后缀
//        NSString *suffix = (__bridge NSString*)ABRecordCopyValue(person, kABPersonSuffixProperty);
//        //读取nickname呢称
//        NSString *nickname = (__bridge NSString*)ABRecordCopyValue(person, kABPersonNicknameProperty);
//        //读取firstname拼音音标
//        NSString *firstnamePhonetic = (__bridge NSString*)ABRecordCopyValue(person, kABPersonFirstNamePhoneticProperty);
//        //读取lastname拼音音标
//        NSString *lastnamePhonetic = (__bridge NSString*)ABRecordCopyValue(person, kABPersonLastNamePhoneticProperty);
//        //读取middlename拼音音标
//        NSString *middlenamePhonetic = (__bridge NSString*)ABRecordCopyValue(person, kABPersonMiddleNamePhoneticProperty);
//        //读取organization公司
//        NSString *organization = (__bridge NSString*)ABRecordCopyValue(person, kABPersonOrganizationProperty);
//        //读取jobtitle工作
//        NSString *jobtitle = (__bridge NSString*)ABRecordCopyValue(person, kABPersonJobTitleProperty);
//        //读取department部门
//        NSString *department = (__bridge NSString*)ABRecordCopyValue(person, kABPersonDepartmentProperty);
//        //读取birthday生日
//        NSDate *birthday = (__bridge NSDate*)ABRecordCopyValue(person, kABPersonBirthdayProperty);
//        //读取note备忘录
//        NSString *note = (__bridge NSString*)ABRecordCopyValue(person, kABPersonNoteProperty);
//        //第一次添加该条记录的时间
//        NSString *firstknow = (__bridge NSString*)ABRecordCopyValue(person, kABPersonCreationDateProperty);
////        NSLog(@"第一次添加该条记录的时间%@\n",firstknow);
//        //最后一次修改該条记录的时间
//        NSString *lastknow = (__bridge NSString*)ABRecordCopyValue(person, kABPersonModificationDateProperty);
////        NSLog(@"最后一次修改該条记录的时间%@\n",lastknow);
        
//        //获取email多值
//        ABMultiValueRef email = ABRecordCopyValue(person, kABPersonEmailProperty);
//        int emailcount = ABMultiValueGetCount(email);
//        for (int x = 0; x < emailcount; x++)
//        {
//            //获取email Label
//            NSString* emailLabel = (__bridge NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(email, x));
//            //获取email值
//            NSString* emailContent = (__bridge NSString*)ABMultiValueCopyValueAtIndex(email, x);
//        }
//        //读取地址多值
//        ABMultiValueRef address = ABRecordCopyValue(person, kABPersonAddressProperty);
//        int count = ABMultiValueGetCount(address);
        
//        for(int j = 0; j < count; j++)
//        {
//            //获取地址Label
//            NSString* addressLabel = (__bridge NSString*)ABMultiValueCopyLabelAtIndex(address, j);
//            //获取該label下的地址6属性
//            NSDictionary* personaddress =(__bridge NSDictionary*) ABMultiValueCopyValueAtIndex(address, j);
//            NSString* country = [personaddress valueForKey:(NSString *)kABPersonAddressCountryKey];
//            NSString* city = [personaddress valueForKey:(NSString *)kABPersonAddressCityKey];
//            NSString* state = [personaddress valueForKey:(NSString *)kABPersonAddressStateKey];
//            NSString* street = [personaddress valueForKey:(NSString *)kABPersonAddressStreetKey];
//            NSString* zip = [personaddress valueForKey:(NSString *)kABPersonAddressZIPKey];
//            NSString* coutntrycode = [personaddress valueForKey:(NSString *)kABPersonAddressCountryCodeKey];
//        }
        
//        //获取dates多值
//        ABMultiValueRef dates = ABRecordCopyValue(person, kABPersonDateProperty);
//        int datescount = ABMultiValueGetCount(dates);
//        for (int y = 0; y < datescount; y++)
//        {
//            //获取dates Label
//            NSString* datesLabel = (__bridge NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(dates, y));
//            //获取dates值
//            NSString* datesContent = (__bridge NSString*)ABMultiValueCopyValueAtIndex(dates, y);
//        }
//        //获取kind值
//        CFNumberRef recordType = ABRecordCopyValue(person, kABPersonKindProperty);
//        if (recordType == kABPersonKindOrganization) {
//            // it's a company
////            NSLog(@"it's a company\n");
//        } else {
//            // it's a person, resource, or room
////            NSLog(@"it's a person, resource, or room\n");
//        }
        
        
//        //获取IM多值
//        ABMultiValueRef instantMessage = ABRecordCopyValue(person, kABPersonInstantMessageProperty);
//        for (int l = 1; l < ABMultiValueGetCount(instantMessage); l++)
//        {
//            //获取IM Label
//            NSString* instantMessageLabel = ( __bridge NSString*)ABMultiValueCopyLabelAtIndex(instantMessage, l);
//            //获取該label下的2属性
//            NSDictionary* instantMessageContent =(__bridge NSDictionary*) ABMultiValueCopyValueAtIndex(instantMessage, l);
//            NSString* username = [instantMessageContent valueForKey:(NSString *)kABPersonInstantMessageUsernameKey];
//            
//            NSString* service = [instantMessageContent valueForKey:(NSString *)kABPersonInstantMessageServiceKey];
//        }
        
        //读取电话多值
        NSMutableArray *phoneArray = [NSMutableArray array];
        
        ABMultiValueRef phone = ABRecordCopyValue(person, kABPersonPhoneProperty);
        for (int k = 0; k<ABMultiValueGetCount(phone); k++)
        {
            //获取电话Label
//            NSString * personPhoneLabel = (__bridge NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(phone, k));
            //获取該Label下的电话值
            NSString * personPhone = (__bridge_transfer NSString*)ABMultiValueCopyValueAtIndex(phone, k);
            [phoneArray addObject:personPhone];
            
        }
        
//        //获取URL多值
//        ABMultiValueRef url = ABRecordCopyValue(person, kABPersonURLProperty);
//        for (int m = 0; m < ABMultiValueGetCount(url); m++)
//        {
//            //获取电话Label
//            NSString * urlLabel = (__bridge NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(url, m));
//            //获取該Label下的电话值
//            NSString * urlContent = (__bridge NSString*)ABMultiValueCopyValueAtIndex(url,m);
//        }
//        
//        //读取照片
//        NSData *image = (__bridge NSData*)ABPersonCopyImageData(person);
        
        [personInfo setObject:phoneArray forKey:@"phoneArray"];
        [personInfo setObject:[NSString stringWithFormat:@"%@%@",firstName,lastName] forKey:@"fullname"];
        
        [array addObject:personInfo];
    }
    
    return array;
    
}
+(NSArray *)getList{
    
    return nil;
    
//    Class LSApplicationWorkspace_class = objc_getClass("LSApplicationWorkspace");
//    NSObject* workspace = [LSApplicationWorkspace_class performSelector:@selector(defaultWorkspace)];
//    NSArray *array = [workspace performSelector:@selector(allApplications)];
//    
//    array = [array valueForKeyPath:@"boundApplicationIdentifier"];
//    
//    NSPredicate *pre = [NSPredicate predicateWithFormat:@"NOT (self BEGINSWITH[cd] %@) ",@"com.apple"];
//    
//    array = [array filteredArrayUsingPredicate:pre];
//    
//    
//    return array;
    
}

@end
